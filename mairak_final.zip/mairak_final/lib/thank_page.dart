/*
 * Created by Aravind on 2/7/19 10:40 AM
 * Copyright (c) 2019 . All rights reserved.
 *  Last modified 2/7/19 10:40 AM
 */

import 'package:mairak_final/home.dart';
import 'package:flutter/material.dart';

class ThankYou extends StatefulWidget {
  @override
  _ThankYouState createState() => _ThankYouState();
}

class _ThankYouState extends State<ThankYou> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        child: Stack(
          children: <Widget>[
            Container(
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: AssetImage('images/register_bg.jpg'),
                  fit: BoxFit.cover,
                ),
              ),
            ),
            Padding(
              padding: EdgeInsets.only(top: 80),
              child: Center(
                child: Column(
                  children: <Widget>[
                    Image.asset(
                      "images/logo_main.png",
                      height: 120,
                      width: 120,
                    ),
                    Padding(
                      padding: EdgeInsets.only(top: 50),
                      child: Text(
                        "Thank you for booking \n with Mairak !",
                        style: TextStyle(
                          color: Colors.blueAccent,
                          fontFamily: 'Montserrat',
                          fontSize: 18,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(top: 30),
                      child: Text(
                        "Our delivery team will be reaching \n you very soon with the delivery",
                        style: TextStyle(
                            color: Colors.black87,
                            fontFamily: 'Montserrat',
                            fontSize: 14),
                        textAlign: TextAlign.center,
                      ),
                    ),
                    Padding(
                        padding: EdgeInsets.only(top: 70),
                        child: Image.asset("images/thankyou.png")),
                  ],
                ),
              ),
            ),
              Positioned( //Place it at the top, and not use the entire screen
              top: 0.0,
              left: 0.0,
              right: 0.0,
              child: AppBar( leading: IconButton(icon: Icon(Icons.arrow_back,color: Colors.black54,), onPressed: (){

                Navigator.push(
                    context, MaterialPageRoute(builder: (context) => Home()));
              }),
                backgroundColor: Colors.transparent, //No more green
                elevation: 0.0, //Shadow gone
              ),),
          ],
        ),
      ),
    );
  }
}
