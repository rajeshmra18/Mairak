/*
 * Created by Aravind on 12/13/18 1:45 PM
 * Copyright (c) 2018 . All rights reserved.
 *  Last modified 12/13/18 1:45 PM
 */


  import 'package:flutter/material.dart';


  class ImageAssets extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Container (child: Text(""));
  }



  }

  class ImageWidgets extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    var assetsImage = AssetImage('images/mairak_logo.png');
    var image = Image(image: assetsImage,width: 80.0,height: 50.0);
    return Container(child: image);
  }


  }

  class SplashImageWidgets extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    var assetsImage = AssetImage('images/sp_bg_comp.jpg');
    var image = Image(image: assetsImage, fit: BoxFit.fill,);
    return Container(child: image);
  }


  }


  class SplashImageBg extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    var assetsImage = AssetImage('images/splash_screen_bg.jpg');
    var image = Image(image: assetsImage,width: 180.0,height: 150.0);
    return Container(child: image);
  }


  }