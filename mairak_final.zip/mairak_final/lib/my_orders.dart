/*
 * Created by Aravind on 1/16/19 4:35 PM
 * Copyright (c) 2019 . All rights reserved.
 *  Last modified 1/16/19 4:35 PM
 */

import 'package:flutter/material.dart';
import 'package:shimmer/shimmer.dart';
import 'allapi.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:async';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  runApp(MaterialApp(
    home: MyOrders(),
  ));
}

class MyOrders extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return MyOrderState();
  }
}

class MyOrderState extends State<MyOrders> {
  List myOrderData;
  String userID = "";
  bool isLoading = true;
  int taxValue = 5;
  bool loading = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
/*
      floatingActionButton: FloatingActionButton(onPressed: (){},child:Icon(Icons.filter_list,color: Colors.black54,) ,backgroundColor: Color(0xffffffff),),
      floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,
*/

        body: Stack(children: <Widget>[
      Center(
        child: isLoading
            ? SizedBox(
                child: Shimmer.fromColors(
                  baseColor: Colors.black12,
                  highlightColor: Colors.white,
                  child: Image.asset(
                    "images/shimmer.png",
                    fit: BoxFit.fill,
                  ),
                  /*  Text(
              'Loading',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 20.0,
                fontWeight:
                FontWeight.bold,
              ),
            ),*/
                ),
              )

            /*   Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  CircularProgressIndicator(),
                  Padding(
                    padding: const EdgeInsets.all(15.0),
                    child: Text("Loading"),
                  )
                ],
              )*/

            : Container(),
      ),
      ListView.builder(
        itemCount: myOrderData == null ? 0 : myOrderData.length,
        itemBuilder: (BuildContext context, int index) {
          return Container(
            height: 110.0,
            child: Card(
              child: Container(
                  child: Padding(
                padding: EdgeInsets.only(left: 10, right: 15),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    Padding(
                        padding: EdgeInsets.only(left: 10),
                        child: Container(
                            width: 60,
                            height: 60,
                            decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: Colors.redAccent),
                            child: Center(
                              child: Text(
                                myOrderData[index]['order_code'],
                                style: TextStyle(
                                    color: Colors.white,
                                    fontFamily: 'Montserrat'),
                                textAlign: TextAlign.center,
                              ),
                            ))),
                    SizedBox(
                      width: 40,
                    ),
                    Padding(
                        padding: EdgeInsets.only(top: 25),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            Expanded(
                              child: Text(
                                myOrderData[index]['delivered_status'],
                                style: TextStyle(
                                    color: Colors.black87,
                                    fontFamily: 'Montserrat'),
                                textAlign: TextAlign.center,
                              ),
                              flex: 1,
                            ),
                            Expanded(
                              child: Text(
                                myOrderData[index]['created_time'],
                                style: TextStyle(
                                    color: Colors.black87,
                                    fontFamily: 'Montserrat',
                                    fontSize: 11),
                                textAlign: TextAlign.center,
                              ),
                              flex: 1,
                            ),
                          ],
                        )),
                    SizedBox(
                      width: 60,
                    ),
                    Padding(
                      padding: EdgeInsets.only(top: 25),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          Expanded(
                            child: Text(
                              myOrderData[index]['created_date'],
                              style: TextStyle(
                                  color: Colors.black87,
                                  fontFamily: 'Montserrat',
                                  fontSize: 12),
                              textAlign: TextAlign.center,
                            ),
                            flex: 1,
                          ),
                          Expanded(
                            child: Text(
                              'inc $taxValue% tax',
                              style: TextStyle(
                                  color: Colors.black54,
                                  fontFamily: 'Montserrat',
                                  fontSize: 10),
                              textAlign: TextAlign.center,
                            ),
                            flex: 1,
                          ),
                          Expanded(
                            child: Text(
                              'AED. ' + myOrderData[index]['total_price'],
                              style: TextStyle(
                                  color: Colors.blueAccent,
                                  fontFamily: 'Montserrat',
                                  fontSize: 12),
                              textAlign: TextAlign.center,
                            ),
                            flex: 1,
                          ),
                        ],
                      ),
                    )
                  ],
                ),
              )),
            ),
          );
        },
      ),
    ]));
  }

  @override
  void initState() {
    isLoading = true;
    getPrefData().then(getLogState);
    getMyOrders();
    super.initState();
  }

  Future<String> getPrefData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String userID = prefs.getString("userID");

    return userID;
  }

  void getLogState(String userID) {
    setState(() {
      print("ShareeVAla" + userID);

      this.userID = userID;
    });
  }

  @override
  void dispose() {
    loading = false;
    super.dispose();
  }

  Future<String> getMyOrders() async {
    final url = Apis.myOrders;
    SharedPreferences prefs = await SharedPreferences.getInstance();

    var response = await http.post(Uri.encodeFull(url),
        headers: {"Accept": "application/json"},
        body: {"user_id": userID, "start_date": "", "end_date": ""});
    setState(() {
      isLoading = false;
    });

    if (response.statusCode == 200) {
      if (loading == true) {
        setState(() {
          Map<String, dynamic> myOrders = jsonDecode(response.body);

          //     print("ProooductOBj" + response.body);

          myOrderData = myOrders['orders'];
        });
      }
    } else {}

    return "Sucess!";
  }
}
