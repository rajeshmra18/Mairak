/*
 * Created by Aravind on 1/25/19 12:09 PM
 * Copyright (c) 2019 . All rights reserved.
 *  Last modified 1/25/19 12:09 PM
 */

import 'package:mairak_final/home.dart';
import 'package:mairak_final/widgets.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Settings extends StatefulWidget {
  final Function chkLang;

  Settings(this.chkLang);

  @override
  State<StatefulWidget> createState() {
    return SettingsState();
  }
}

class SettingsState extends State<Settings> {
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  bool _giveVerse = false;

  String lang = "Language", eng = "English", arb = "Arabic";

  @override
  void initState() {
    super.initState();
    _chkLang();
    getPrefData();
  }

  Future<void> getPrefData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String lang = prefs.getString("language");

    if (lang == "a") {
      setState(() {
        _giveVerse = true;
      });
    } else {
      setState(() {
        _giveVerse = false;
      });
    }
  }

  _chkLang() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    if (prefs.getString("language") == "a") {
      lang = "اختر لغتك المفضلة";
      eng = "الإنجليزية";
      arb = "العربية";
    } else {
      lang = "Language";
      eng = "English";
      arb = "Arabic";
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      resizeToAvoidBottomPadding: false,
      appBar: AppBar(
        leading: IconButton(
            icon: Icon(Icons.arrow_back),
            onPressed: () {
              Navigator.push(
                  context, MaterialPageRoute(builder: (context) => Home()));
            }),
        title: ImageWidgets(),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.only(top: 0),
        child: Container(
          child: Column(
            children: <Widget>[
              Container(
                height: 110,
                child: Card(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: <Widget>[
                      Padding(
                        padding:
                            const EdgeInsets.only(top: 10, left: 15, bottom: 8),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: <Widget>[
                            Icon(
                              Icons.translate,
                              size: 15,
                            ),
                            SizedBox(
                              width: 10,
                            ),
                            Text(
                              "$lang",
                              style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 16,
                                  fontFamily: 'Montserrat'),
                            )
                          ],
                        ),
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                          Padding(
                            padding: const EdgeInsets.only(left: 50.0),
                            child: Text(
                              "$eng",
                              style: TextStyle(fontFamily: 'Montserrat'),
                            ),
                          ),
                          Container(
                            child: Switch(
                              value: _giveVerse,
                              onChanged: (bool newValue) {
                                widget.chkLang();
                                setState(() {
                                  _changeLang(newValue);

                                  _giveVerse = newValue;
                                });
                              },
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(right: 50.0),
                            child: Text(
                              "$arb",
                              style: TextStyle(fontFamily: 'Montserrat'),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _changeLang(bool newValue) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    print(newValue);
    if (newValue == true) {
      prefs.setString('language', "a");
    } else {
      prefs.setString('language', "e");
    }
  }
}
