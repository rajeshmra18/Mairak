/*
 * Created by Aravind on 1/9/19 4:12 PM
 * Copyright (c) 2019 . All rights reserved.
 *  Last modified 1/9/19 3:21 PM
 */

import 'package:mairak_final/productListing/pre_book.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'dart:async';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:mairak_final/allapi.dart';
import 'package:flutter/cupertino.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:shimmer/shimmer.dart';

class ProductListInflate extends StatefulWidget {
  final Function callback;

  ProductListInflate(this.callback);

  @override
  State<StatefulWidget> createState() {
    return new ProductListInflateState();
  }
}

class ProductListInflateState extends State<ProductListInflate> {
  List productsData;
  bool loading = true;
  int quantVal = 1;
  var quantController = TextEditingController();
  bool isLoading = true;
  String language = "e";
  String add = "ADD", preBook = "Pre Book", close = "Close";
  final GlobalKey<ScaffoldState> _scaffoldKeyP = GlobalKey<ScaffoldState>();

  void _chkLang() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    if (prefs.getString("language") == "a") {
      add = "إضافة";
      preBook = "الطلبات المقدمة";
      close = "إلغاء";
    } else {
      close = "Close";
      add = "ADD";
      preBook = "Pre Book";
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        key: _scaffoldKeyP,
        body: Stack(
          children: <Widget>[
            Center(
              /*child: Column(mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[

                      CircularProgressIndicator(),
                      Padding(
                        padding: const EdgeInsets.all(15.0),
                        child: Text("Loading"),
                      )
                    ],
                  )*/

              child: isLoading
                  ? SizedBox(
                      child: Shimmer.fromColors(
                        baseColor: Colors.black12,
                        highlightColor: Colors.white,
                        child: Image.asset(
                          "images/shimmer.png",
                          fit: BoxFit.fill,
                        ),
                        /*  Text(
              'Loading',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 20.0,
                fontWeight:
                FontWeight.bold,
              ),
            ),*/
                      ),
                    )
                  /*    Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        CircularProgressIndicator(),
                        Padding(
                          padding: const EdgeInsets.all(15.0),
                          child: Text("Loading"),
                        )
                      ],
                    )
              */

                  : Container(),
            ),
            Container(
              child: ListView.builder(
                itemCount: productsData == null ? 0 : productsData.length,
                itemBuilder: (BuildContext context, int index) {
                  return Container(
                    height: 150.0,
                    child: Card(
                      child: Container(
//        decoration: index % 2 == 0
//            ? new BoxDecoration(color: Color.fromRGBO(FF, FF, b, opacity))
//            : new BoxDecoration(color: const Color(0xFF7ec0ee)),
                        child: Row(
                          children: <Widget>[
                            Container(
                              margin: EdgeInsets.all(10.0),
                              child:

                                  /*
                      Image(
                          image: NetworkImage(productsData[index]['images']),
                          width: 90.0,
                          height: 150.0),*/

                                  Stack(
                                children: <Widget>[
                                  /* Center(
                                      widthFactor: 2.8,
                                      child: CircularProgressIndicator(
                                        strokeWidth: 2,
                                      )),*/
                                  Center(
                                      child: Container(
                                    width: 95.0,
                                    height: 150.0,
                                    child: CachedNetworkImage(
                                      imageUrl: Uri.encodeFull(
                                          productsData[index]['images']),
                                      placeholder: CircularProgressIndicator(
                                        strokeWidth: 2,
                                      ),
                                      height: 100,
                                      width: 90,
                                      errorWidget: Icon(
                                        Icons.broken_image,
                                        size: 32,
                                        color: Colors.grey,
                                      ),
                                    ),
                                  )

                                      /*   FadeInImage.memoryNetwork(
                                      width: 90.0,
                                      height: 150.0,
                                      placeholder: kTransparentImage,
                                      image: Uri.encodeFull(
                                          productsData[index]['images']),
                                    ),*/
                                      ),
                                ],
                              ),
                            ),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                Container(
                                  padding: const EdgeInsets.only(bottom: 10.0),
                                  child: Text(
                                    productsData[index]['product_name'],
                                    style: TextStyle(
                                        fontSize: 18.0,
                                        fontFamily: 'Montserrat',
                                        color: const Color(0xff07a7cf)),
                                  ),
                                ),
                                Flexible(
                                  child: Container(
                                    width: 210,
                                    padding: const EdgeInsets.only(
                                        bottom: 10.0, right: 1.0),
                                    child: Text(
                                      productsData[index]['description'],
                                      overflow: TextOverflow.ellipsis,
                                      softWrap: false,
                                      maxLines: 1,
                                      style: TextStyle(
                                          fontWeight: FontWeight.normal,
                                          fontFamily: 'Montserrat',
                                          fontSize: 10.0,
                                          color: Colors.black87),
                                    ),
                                  ),
                                ),
                                Row(
                                  children: <Widget>[
                                    Container(
                                      padding:
                                          const EdgeInsets.only(bottom: 6.0),
                                      child: Text(
                                        'AED. ',
                                        style: TextStyle(
                                            fontSize: 13.0,
                                            fontFamily: 'Montserrat',
                                            color: const Color(0xff07a7cf)),
                                      ),
                                    ),
                                    Container(
                                      padding:
                                          const EdgeInsets.only(bottom: 6.0),
                                      child: Text(
                                        productsData[index]['price'],
                                        style: TextStyle(
                                            fontSize: 14.0,
                                            fontFamily: 'Montserrat',
                                            color: const Color(0xff07a7cf)),
                                      ),
                                    ),
                                  ],
                                ),
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: <Widget>[
                                    // addButton,

                                    Padding(
                                      padding: EdgeInsets.only(right: 5.0),
                                      child: RaisedButton(
                                        shape: RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(24),
                                        ),

                                        onPressed: () {
                                          _showDialog(index);
                                        },

                                        padding: EdgeInsets.all(8),
                                        // color: const Color(0xff07a7cf),
                                        color: const Color(0xff1a606f),

                                        child: Text(add,
                                            style: TextStyle(
                                                color: Colors.white,
                                                fontFamily: 'Montserrat')),
                                      ),
                                    ),

                                    Padding(
                                      padding:
                                          EdgeInsets.only(right: 5.0, left: 10),
                                      child: RaisedButton(
                                        shape: RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(24),
                                        ),

                                        onPressed: () {
                                          _showPreDialog(index);
                                        },

                                        padding: EdgeInsets.all(8),
                                        // color: const Color(0xff07a7cf),
                                        color: const Color(0xff1a606f),

                                        child: Text(preBook,
                                            style: TextStyle(
                                                color: Colors.white,
                                                fontFamily: 'Montserrat')),
                                      ),
                                    ),
                                  ],
                                )
                              ],
                            )
                          ],
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ));

    /*  ListView(

      children: _buildListItemsFromProducts(context),
    );*/
  }

  final addButton = Padding(
    padding: EdgeInsets.only(right: 5.0),
    child: RaisedButton(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(24),
      ),
      onPressed: () {
        // addDialog();
      },

      padding: EdgeInsets.all(12),
      // color: const Color(0xff07a7cf),
      color: const Color(0xff1a606f),

      child: Text('ADD',
          style: TextStyle(color: Colors.white, fontFamily: 'Montserrat')),
    ),
  );

  void addDia() {
    // flutter defined function
    showDialog(
      context: context,
      builder: (BuildContext context) {
        // return object of type Dialog
        return AlertDialog(
          title: Text("Alert Dialog title"),
          content: Text("Alert Dialog body"),
          actions: <Widget>[
            // usually buttons at the bottom of the dialog
            new FlatButton(
              child: new Text("Close"),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  @override
  void initState() {
    super.initState();
    _chkLang();
    getSharedData();
    getProducts();
    quantController.text = "1";
    widget.callback();
    setState(() {
      isLoading = true;
    });
  }

  @override
  void dispose() {
    super.dispose();
    loading = false;
    quantController.dispose();
  }

  @override
  void deactivate() {
    super.deactivate();
    _chkLang();
    getProducts();
  }

  Future<String> getProducts() async {
    final url = Apis.productsList;
    SharedPreferences prefs = await SharedPreferences.getInstance();
    var response;
    print("Langgggggggg" + language);
    response = await http.post(Uri.encodeFull(url), headers: {
      "Accept": "application/json"
    }, body: {
      "secret_hash": "W9zUnkWf5wJS27Yb2Nmmz3T",
      "language": prefs.getString("language")
    });

    // print("rEEESSPPSPSPSProooooooo" + response.body);

    if (loading == true) {
      setState(() {
        isLoading = false;
      });
    }

    if (response.statusCode == 200) {
      if (loading == true) {
        setState(() {
          Map<String, dynamic> products = jsonDecode(response.body);
          productsData = products['products'];
          //print('Howdy2222, ${products['products'][0]['product_name']}!');
        });
      }
    } else {}

    return "Sucess!";
  }

  _showDialog(int index) async {
    await showDialog<String>(
      context: context,
      builder: (BuildContext context) {
        return CupertinoAlertDialog(
          //   title:  Text(productsData[index]['product_name']),
          actions: <Widget>[
            CupertinoDialogAction(
              isDestructiveAction: true,
              onPressed: () {
                Navigator.of(context).pop('Close');
              },
              child: Text(
                '$close',
                style: TextStyle(
                    fontFamily: 'Montserrat', color: Colors.redAccent),
              ),
            ),
            /*  CupertinoDialogAction(
              textStyle: TextStyle(color: Colors.blue),
              isDestructiveAction: true,
              onPressed: () {
                Navigator.of(context).pop('Accept');
              },
              child:  Text('Add to cart', style: TextStyle(color: Colors.blue, fontFamily: 'Montserrat',),),
            ),*/
          ],
          content: SingleChildScrollView(
            child: Material(
              color: Colors.transparent,
              child: MyDialogContent(
                productData: productsData,
                index: index,
                sPriceVal: (double.parse(productsData[index]['price'])),
                callBack: widget.callback,
                scaffoldKeyP: _scaffoldKeyP,
              ),
            ),
          ),
        );
      },
      barrierDismissible: false,
    );
  }

  _showPreDialog(int index) async {
    await showDialog<String>(
      context: context,
      builder: (BuildContext context) {
        return CupertinoAlertDialog(
          //   title:  Text(productsData[index]['product_name']),
          actions: <Widget>[
            CupertinoDialogAction(
              isDestructiveAction: true,
              onPressed: () {
                Navigator.of(context).pop('Close');
              },
              child: Text(
                '$close',
                style: TextStyle(
                    fontFamily: 'Montserrat', color: Colors.redAccent),
              ),
            ),
            /*  CupertinoDialogAction(
              textStyle: TextStyle(color: Colors.blue),
              isDestructiveAction: true,
              onPressed: () {
                Navigator.of(context).pop('Accept');
              },
              child:  Text('Add to cart', style: TextStyle(color: Colors.blue, fontFamily: 'Montserrat',),),
            ),*/
          ],
          content: SingleChildScrollView(
            child: Material(
              color: Colors.transparent,
              child: PreOrderDialog(
                productData: productsData,
                index: index,
                sPriceVal: (double.parse(productsData[index]['price'])),
                callBack: widget.callback,
                scaffoldKeyP: _scaffoldKeyP,
              ),
            ),
          ),
        );
      },
      barrierDismissible: false,
    );
  }

  Future<void> getSharedData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      language = prefs.getString("language");
    });
    print("laanngggg" + language);
  }
}

final preButton = Padding(
  padding: EdgeInsets.only(right: 5.0, left: 10),
  child: RaisedButton(
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(24),
    ),

    onPressed: () {
//          Navigator.pushNamed(context,'/Home');
      //   Navigator.of(context).pushNamed(Home.tag);
/*      Navigator.pushReplacement(context, new MaterialPageRoute(
          builder: (context) =>
          new Home())
      );*/
    },

    padding: EdgeInsets.all(8),
    // color: const Color(0xff07a7cf),
    color: const Color(0xff1a606f),

    child: Text('PRE BOOK',
        style: TextStyle(color: Colors.white, fontFamily: 'Montserrat')),
  ),
);

Future<bool> addDialog(final BuildContext context) {
  return showDialog(
    context: context,
    builder: (BuildContext context) {
      // return object of type Dialog
      return AlertDialog(
        title: new Text("Alert Dialog title"),
        content: new Text("Alert Dialog body"),
        actions: <Widget>[
          // usually buttons at the bottom of the dialog
          new FlatButton(
            child: new Text("Close"),
            onPressed: () {
              Navigator.of(context).pop();
            },
          ),
        ],
      );
    },
  );
}

class MyDialogContent extends StatefulWidget {
  final Function callBack;

  MyDialogContent(
      {Key key,
      this.productData,
      this.index,
      this.sPriceVal,
      this.callBack,
      this.scaffoldKeyP})
      : super(key: key);

  final int index;
  final List productData;
  final GlobalKey<ScaffoldState> scaffoldKeyP;
  double sPriceVal = 0.0;
  bool isAddedToCart = false;

  @override
  MyDialogContentState createState() => MyDialogContentState();
}

class MyDialogContentState extends State<MyDialogContent> {
  int quantityVal = 1;
  String userID = "", addToCartT = "ADD TO CART";
  bool isCallingApi = false;
  final quantController = TextEditingController();



  void _chkLang() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    if (prefs.getString("language") == "a") {
      addToCartT = "إضافة";
    } else {
      addToCartT = "ADD";
    }
  }

  @override
  void initState() {
    quantController.text = "1";
    _chkLang();
    getPrefData().then(getUserData);
    super.initState();
  }

  _getContent() {
    String url = widget.productData[widget.index]['images'];

    return isCallingApi
        ? Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              SizedBox(
                height: 15,
              ),
              CircularProgressIndicator(),
              Padding(
                padding: const EdgeInsets.all(15.0),
                child: Text("Adding To Cart"),
              )
            ],
          )
        : Container(
            height: 400.0,
            decoration: BoxDecoration(color: Colors.transparent),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Expanded(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      /*    Image(
                    image: NetworkImage(

                        widget.productData[widget.index]['images']),
                    width: 90.0,
                    height: 140.0),*/

/*

                    CachedNetworkImage(
                                     placeholder: CircularProgressIndicator(),
                                      imageUrl: Uri.encodeFull(url),
                                 ),
*/

                      Stack(
                        children: <Widget>[
                          /*  Center(
                              heightFactor: 3,
                              child: CircularProgressIndicator()),*/

                          Center(
                              child: Container(
                            width: 200.0,
                            height: 180.0,
                            child: CachedNetworkImage(
                              imageUrl: Uri.encodeFull(url),
                              placeholder: CircularProgressIndicator(
                                strokeWidth: 2,
                              ),
                              height: 100,
                              width: 90,
                              errorWidget: Icon(
                                Icons.broken_image,
                                size: 32,
                                color: Colors.grey,
                              ),
                            ),
                          )

                              /*
                            child:
                            FadeInImage.memoryNetwork(
                              width: 200.0,
                              height: 180.0,
                              placeholder: kTransparentImage,
                              image: Uri.encodeFull(url),
                            ),
*/

                              ),
                        ],
                      ),
                      Padding(
                        padding: EdgeInsets.only(top: 4.0),
                        child: Text(
                            widget.productData[widget.index]['product_name'],
                            style: TextStyle(
                                fontSize: 18.0,
                                fontFamily: 'Montserrat',
                                color: const Color(0xff07a7cf))),
                      ),
                      Padding(
                        padding: EdgeInsets.only(top: 2.0),
                        child: Text(
                            widget.productData[widget.index]['description'],
                            maxLines: 3,
                            overflow: TextOverflow.ellipsis,
                            textAlign: TextAlign.center,
                            style: TextStyle(
                                fontSize: 10.0,
                                fontFamily: 'Montserrat',
                                color: Colors.black87)),
                      ),
                      Padding(
                        padding: EdgeInsets.only(top: 7.0),
                        child: Text(
                          // priceVal.toString(),
                          "AED. ${widget.sPriceVal.toString()}",
                          style: new TextStyle(
                              fontSize: 14.0,
                              fontFamily: 'Montserrat',
                              color: const Color(0xff07a7cf)),
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.only(top: 6.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            Container(
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                ),
                                child: MaterialButton(
                                  onPressed: () {



                                    setState(() {


                                      if (quantityVal > 1) {
                                        quantityVal--;
                                        quantController.text = quantityVal.toString();
                                      }

                                      widget.sPriceVal = quantityVal *
                                          double.parse(
                                              widget.productData[widget.index]
                                                  ['price']);

                                      print("decValll : " +
                                          quantityVal.toString() +
                                          " " +
                                          widget.productData[widget.index]
                                                  ['price']
                                              .toString() +
                                          " " +
                                          widget.sPriceVal.toString());

                                    });
                                  },
                                  child: Icon(
                                    Icons.remove,
                                    size: 20,
                                  ),
                                  minWidth: 10,
                                )),
                            Container(
                                decoration: BoxDecoration(
                                    // color: Colors.black12,
                                    ),
                                width: 30,
                                child:
                              /*
                                Text(
                                  quantityVal.toString(),
                                  style: TextStyle(fontSize: 15),
                                  textAlign: TextAlign.center,
                                  softWrap: false,
                                )*/

                                         TextField(

                                                              keyboardType:
                                                                  TextInputType
                                                                      .number,
                                                              controller: quantController,
                                                              onChanged: (d){
                                                                print("Oncha"+d);
                                                                if(int.parse(d)>0){
                                                                  setState(() {
                                                                    quantityVal = int.parse(d);
                                                                    widget.sPriceVal = quantityVal *
                                                                        double.parse(
                                                                            widget.productData[widget.index]
                                                                            ['price']);
                                                                  });

                                                                }else{
                                                                  setState(() {
                                                                    quantityVal = 1;
                                                                    widget.sPriceVal = quantityVal *
                                                                        double.parse(
                                                                            widget.productData[widget.index]
                                                                            ['price']);
                                                                  });
                                                                }

                                                              },
                                                              autofocus: false,
                                                              textAlign: TextAlign.center,
                                                              style: TextStyle(
                                                                  fontFamily:

                                                                      'Montserrat',
                                                                  color: Colors
                                                                      .black),
                                                              decoration:
                                                                  InputDecoration(
                                                                    border: InputBorder.none,
                                                                    fillColor: Colors.red,
                                                               /*  border: OutlineInputBorder(
                                                                    borderRadius:
                                                                        BorderRadius.circular(
                                                                            5)),*/
                                                              ),
                                                            ),

                                ),
                            Container(
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                ),
                                child: MaterialButton(
                                  onPressed: () {
                                    setState(() {
                                      quantityVal++;
                                      quantController.text = quantityVal.toString();
                                      widget.sPriceVal = quantityVal *
                                          double.parse(widget
                                              .productData[widget.index]
                                                  ['price']
                                              .toString());
                                      print("PriceVzal  : " +
                                          widget.sPriceVal.toString());
                                    int newQuant =
                                int.parse(
                                    quantController
                                        .text);

                                quantController
                                    .text =
                                    (newQuant++)
                                        .toString();
                                    });
                                  },
                                  child: Icon(Icons.add),
                                  minWidth: 10,
                                )),
                          ],
                        ),
                      )
                    ],
                  ),
                  flex: 5,
                ),
                Expanded(
                  child: Align(
                    alignment: Alignment.bottomCenter,
                    child: Container(
                      height: 40,
                      child: Padding(
                          padding: EdgeInsets.only(top: 0.0, bottom: 8),
                          child: FlatButton(
                            onPressed: () {
                              print("Quanntity Valueee : " +
                                  quantityVal.toString());

                              addToCart(quantityVal.toString());

                              //  widget.callBack;
                            },

                            child: Text(
                              "$addToCartT",
                              style: TextStyle(
                                  color: CupertinoColors.activeBlue,
                                  fontFamily: 'Montserrat'),
                            ),
                            // color: const Color(0xff1a606f),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(24),
                            ),
                          )),
                    ),
                  ),
                  flex: 0,
                ),
              ],
            ),
          );
  }

  @override
  Widget build(BuildContext context) {
    return _getContent();
  }

  Future<String> addToCart(String quantityVal) async {
    final url = Apis.addToCart;

    setState(() {
      isCallingApi = true;
    });

    print(" MEeeeeeee  : :: :   "+quantController.text);

    var response = await http.post(Uri.encodeFull(url), body: {
      "p_id": (widget.productData[widget.index]['id']).toString(),
      "userid": userID.toString(),
      "qnty": quantController.text,
      "price": (widget.sPriceVal).toString(),
      "lat": "0.00",
      "lng": "0.00",
    });

    setState(() {
      isCallingApi = false;
    });

    Navigator.of(context).pop('Dialog');

    if (response.statusCode == 200) {
      Map<String, dynamic> addCartCall = jsonDecode(response.body);

      print('Howdy, ${addCartCall['Response']['message']}!');

      widget.scaffoldKeyP.currentState.showSnackBar(SnackBar(
        content: Text("${addCartCall['Response']['message']}"),
        duration: Duration(seconds: 2),
      ));

      widget.callBack();

      /*    Fluttertoast.instance.showToast(
          msg: "${addCartCall['Response']['message']}",
          toastLength: Toast.LENGTH_LONG,
          gravity: ToastGravity.BOTTOM,
          timeInSecForIos: 1,
          backgroundColor: Colors.red,
          textColor: Colors.white);*/
    } else {
      throw Exception('Failed to load post');
    }

    return "Sucess!";
  }

  Future<String> getPrefData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String logVal = prefs.getString("userID");

    return logVal;
  }

  void getUserData(String userID) {
    setState(() {
      this.userID = userID;
    });
  }
}
