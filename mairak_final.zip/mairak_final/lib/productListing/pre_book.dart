/*
 * Created by Aravind on 14/2/19 11:03 AM
 * Copyright (c) 2019 . All rights reserved.
 *  Last modified 14/2/19 11:03 AM
 */

import 'dart:convert';
import 'package:mairak_final/allapi.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:intl/intl.dart';
import 'package:datetime_picker_formfield/datetime_picker_formfield.dart';
import 'package:http/http.dart' as http;

class PreOrderDialog extends StatefulWidget {
  final Function callBack;

  PreOrderDialog(
      {Key key,
      this.productData,
      this.index,
      this.sPriceVal,
      this.callBack,
      this.scaffoldKeyP})
      : super(key: key);

  final int index;
  final List productData;
  final GlobalKey<ScaffoldState> scaffoldKeyP;
  double sPriceVal = 0.0;
  bool isAddedToCart = false;

  @override
  PreOrderDialogContentState createState() => PreOrderDialogContentState();
}

class PreOrderDialogContentState extends State<PreOrderDialog> {
  int quantityVal = 1;
  String userID = "", addToCartT = "ADD TO CART";
  bool isCallingApi = false;

  final formats = {
    InputType.date: DateFormat('yyyy-MM-dd'),
    InputType.time: DateFormat("hh:mm a"),
  };

  final dateFormat = DateFormat("EEEE, MMMM d, yyyy 'at' h:mma");
  final timeFormat = DateFormat("h:mm");

  DateTime date;
  DateTime time;

  InputType inputType = InputType.date;
  InputType inputType2 = InputType.time;
  bool editable = true;

  void _chkLang() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    if (prefs.getString("language") == "a") {
      addToCartT = "إضافة";
    } else {
      addToCartT = "ADD";
    }
  }

  @override
  void initState() {
    _chkLang();
    getPrefData().then(getUserData);
    super.initState();
  }

  _getContent() {
    String url = widget.productData[widget.index]['images'];

    return isCallingApi
        ? Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              SizedBox(
                height: 15,
              ),
              CircularProgressIndicator(),
              Padding(
                padding: const EdgeInsets.all(15.0),
                child: Text("Adding To Cart"),
              )
            ],
          )
        : Container(
            height: 400.0,
            decoration: BoxDecoration(color: Colors.transparent),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Expanded(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      /*    Image(
                    image: NetworkImage(

                        widget.productData[widget.index]['images']),
                    width: 90.0,
                    height: 140.0),*/

/*

                    CachedNetworkImage(
                                     placeholder: CircularProgressIndicator(),
                                      imageUrl: Uri.encodeFull(url),
                                 ),
*/

                      Stack(
                        children: <Widget>[
                          /*  Center(
                              heightFactor: 3,
                              child: CircularProgressIndicator()),*/

                          Center(
                              child: Container(
                            width: 170.0,
                            height: 150.0,
                            child: CachedNetworkImage(
                              imageUrl: Uri.encodeFull(url),
                              placeholder: CircularProgressIndicator(
                                strokeWidth: 2,
                              ),
                              height: 100,
                              width: 90,
                              errorWidget: Icon(
                                Icons.broken_image,
                                size: 32,
                                color: Colors.grey,
                              ),
                            ),
                          )

                              /*
                            child:
                            FadeInImage.memoryNetwork(
                              width: 200.0,
                              height: 180.0,
                              placeholder: kTransparentImage,
                              image: Uri.encodeFull(url),
                            ),
*/

                              ),
                        ],
                      ),
                      Padding(
                        padding: EdgeInsets.only(top: 4.0),
                        child: Text(
                            widget.productData[widget.index]['product_name'],
                            style: TextStyle(
                                fontSize: 18.0,
                                fontFamily: 'Montserrat',
                                color: const Color(0xff07a7cf))),
                      ),
                      Padding(
                        padding: EdgeInsets.only(top: 2.0),
                        child: Text(
                            widget.productData[widget.index]['description'],
                            maxLines: 3,
                            overflow: TextOverflow.ellipsis,
                            textAlign: TextAlign.center,
                            style: TextStyle(
                                fontSize: 10.0,
                                fontFamily: 'Montserrat',
                                color: Colors.black87)),
                      ),
                      Padding(
                        padding: EdgeInsets.only(top: 7.0),
                        child: Text(
                          // priceVal.toString(),
                          "AED. ${widget.sPriceVal.toString()}",
                          style: new TextStyle(
                              fontSize: 14.0,
                              fontFamily: 'Montserrat',
                              color: const Color(0xff07a7cf)),
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.only(top: 6.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            Container(
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                ),
                                child: MaterialButton(
                                  onPressed: () {
                                    setState(() {
                                      if (quantityVal > 1) {
                                        quantityVal--;
                                      }

                                      widget.sPriceVal = quantityVal *
                                          double.parse(
                                              widget.productData[widget.index]
                                                  ['price']);

                                      print("decValll : " +
                                          quantityVal.toString() +
                                          " " +
                                          widget.productData[widget.index]
                                                  ['price']
                                              .toString() +
                                          " " +
                                          widget.sPriceVal.toString());

                                      /*    int newQuant =
                                int.parse(
                                    quantController
                                        .text);

                                if (newQuant >
                                    1)
                                  quantController
                                      .text =
                                      (newQuant--)
                                          .toString();*/
                                    });
                                  },
                                  child: Icon(
                                    Icons.remove,
                                    size: 20,
                                  ),
                                  minWidth: 10,
                                )),
                            Container(
                                decoration: BoxDecoration(
                                    // color: Colors.black12,
                                    ),
                                width: 30,
                                child: Text(
                                  quantityVal.toString(),
                                  style: TextStyle(fontSize: 15),
                                  textAlign: TextAlign.center,
                                  softWrap: false,
                                )

                                /*         TextFormField(

                                                              keyboardType:
                                                                  TextInputType
                                                                      .number,
                                                              controller: quantController,
                                                              autofocus: false,
                                                              textAlign: TextAlign.center,
                                                              style: TextStyle(
                                                                  fontFamily:

                                                                      'Montserrat',
                                                                  color: Colors
                                                                      .black),
                                                              decoration:
                                                                  InputDecoration(
                                                                    border: InputBorder.none,
                                                                    fillColor: Colors.red,
                                                                 border: OutlineInputBorder(
                                                                    borderRadius:
                                                                        BorderRadius.circular(
                                                                            5)),
                                                              ),
                                                            ),*/

                                ),
                            Container(
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                ),
                                child: MaterialButton(
                                  onPressed: () {
                                    setState(() {
                                      quantityVal++;
                                      widget.sPriceVal = quantityVal *
                                          double.parse(widget
                                              .productData[widget.index]
                                                  ['price']
                                              .toString());
                                      print("PriceVzal  : " +
                                          widget.sPriceVal.toString());
                                      /* int newQuant =
                                int.parse(
                                    quantController
                                        .text);

                                quantController
                                    .text =
                                    (newQuant++)
                                        .toString();*/
                                    });
                                  },
                                  child: Icon(Icons.add),
                                  minWidth: 10,
                                )),
                          ],
                        ),
                      )
                    ],
                  ),
                  flex: 5,
                ),
                Expanded(
                  child: Row(
                    children: <Widget>[
                      Flexible(
                        child: DateTimePickerFormField(
                          inputType: inputType,
                          initialDate: DateTime.now(),
                          format: formats[inputType],
                          dateOnly: true,
                          editable: editable,
                          style: TextStyle(fontSize: 12, color: Colors.black),
                          decoration: InputDecoration(
                            labelText: 'Date',
                            hasFloatingPlaceholder: true,
                            border: InputBorder.none,
                          ),
                          onChanged: (dt) => setState(() => date = dt),
                        ),
                      ),
                      Flexible(
                        child: DateTimePickerFormField(
                          inputType: inputType2,
                          initialTime: TimeOfDay.now(),
                          format: formats[inputType2],
                          editable: editable,
                          style: TextStyle(fontSize: 12, color: Colors.black),
                          decoration: InputDecoration(
                            labelText: 'Time',
                            hasFloatingPlaceholder: true,
                            border: InputBorder.none,
                          ),
                          onChanged: (dt) => setState(() => time = dt),
                        ),
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: Align(
                    alignment: Alignment.bottomCenter,
                    child: Container(
                      height: 40,
                      child: Padding(
                          padding: EdgeInsets.only(top: 0.0, bottom: 8),
                          child: FlatButton(
                            onPressed: () {
                              print("Quanntity Valueee : " +
                                  quantityVal.toString());

                              print(date.toString());

                              if (date == null || time == null) {
                                widget.scaffoldKeyP.currentState
                                    .showSnackBar(SnackBar(
                                  content: Text("Date and Time can't be Empty"),
                                  duration: Duration(seconds: 1),
                                ));
                              } else if (date.isAfter(DateTime.now())) {
                                widget.scaffoldKeyP.currentState.showSnackBar(
                                    SnackBar(
                                        content: Text(
                                            "Please select an advanced date"),
                                        duration: Duration(seconds: 2)));
                              } else {
                                addToCart(quantityVal.toString());
                              }

                              //  widget.callBack;
                            },
                            child: Text(
                              "$addToCartT",
                              style: TextStyle(
                                  color: CupertinoColors.activeBlue,
                                  fontFamily: 'Montserrat'),
                            ),
                            // color: const Color(0xff1a606f),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(24),
                            ),
                          )),
                    ),
                  ),
                  flex: 0,
                ),
              ],
            ),
          );
  }

  @override
  Widget build(BuildContext context) {
    return _getContent();
  }

  Future<String> addToCart(String quantityVal) async {
    final url = Apis.preOrder;

    var formatter = DateFormat('yyyy-MM-dd');
    var formatterTime = DateFormat('hh:mma');
    String formattedDate = formatter.format(date);
    String formattedTime = formatterTime.format(time);

    print(formattedDate + " : " + formattedTime);

    setState(() {
      isCallingApi = true;
    });

    var response = await http.post(Uri.encodeFull(url), body: {
      "product_id": (widget.productData[widget.index]['id']).toString(),
      "user_id": userID.toString(),
      "quantity": quantityVal,
      "price": (widget.sPriceVal).toString(),
      "preorder_date": formattedDate,
      "preorder_time": formattedTime,
      "location_lat": "0.00",
      "location_long": "0.00",
    });

    setState(() {
      isCallingApi = false;
    });

    Navigator.of(context).pop('Dialog');

    if (response.statusCode == 200) {
      Map<String, dynamic> addCartCall = jsonDecode(response.body);

      print('Howdy, ${addCartCall['Response']['message']}!');

      widget.scaffoldKeyP.currentState.showSnackBar(SnackBar(
        content: Text("${addCartCall['Response']['message']}"),
        duration: Duration(seconds: 2),
      ));

      widget.callBack();

      /*    Fluttertoast.instance.showToast(
          msg: "${addCartCall['Response']['message']}",
          toastLength: Toast.LENGTH_LONG,
          gravity: ToastGravity.BOTTOM,
          timeInSecForIos: 1,
          backgroundColor: Colors.red,
          textColor: Colors.white);*/
    } else {
      throw Exception('Failed to load post');
    }

    return "Sucess!";
  }

  Future<String> getPrefData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String logVal = prefs.getString("userID");

    return logVal;
  }

  void getUserData(String userID) {
    setState(() {
      this.userID = userID;
    });
  }
}
