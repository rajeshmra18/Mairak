/*
 * Created by Aravind on 1/18/19 12:08 PM
 * Copyright (c) 2019 . All rights reserved.
 *  Last modified 1/18/19 12:08 PM
 */

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:mairak_final/allapi.dart';

import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'package:shimmer/shimmer.dart';


void main() {
  runApp(MaterialApp(
    home: OfferListing(),
  ));
}

class OfferListing extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {

    return OfferListingState();
  }
}

class OfferListingState extends State<OfferListing> {
  String userID;

  bool isLoading = true;
  List myOfferData;
  bool loading = true;

  String  to ="to",bookNow = "Book Now",quantity = "Quantity",noOffers="";


  @override
  void deactivate() {
    _chkLang();
    super.deactivate();
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
        body: Stack(
      children: <Widget>[
        Center(
          child: isLoading
              ?
          SizedBox(
            child: Shimmer.fromColors(
              baseColor: Colors.black12,
              highlightColor: Colors.white,
              child:

              Image.asset("images/shimmer.png",fit: BoxFit.fill,),
              /*  Text(
              'Loading',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 20.0,
                fontWeight:
                FontWeight.bold,
              ),
            ),*/
            ),
          )

     /*     Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    CircularProgressIndicator(),
                    Padding(
                      padding: const EdgeInsets.all(15.0),
                      child: Text("Loading"),
                    )
                  ],
                )
          */

              : myOfferData == null ? Center(
            child: Text("$noOffers"),
          ): ListView.builder(
            itemCount: myOfferData == null ? 0 : myOfferData.length,
            itemBuilder: (BuildContext context, int index) {
              return Container(
                height: 250.0,
                child: Card(
                  child: Container(
                      child: Padding(
                          padding: EdgeInsets.only(left: 10, right: 15),
                          child: GestureDetector(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                Padding(
                                  padding: EdgeInsets.only(top: 0),
                                  child: Stack(
                                    children: <Widget>[
                                     /* Center(
                                          widthFactor: 10,
                                          heightFactor: 1.5,
                                          child: CircularProgressIndicator(
                                            strokeWidth: 2,
                                          )),*/
                                      Center(
                                        child:  Container(
                                          height: 95.0,
                                          child:  CachedNetworkImage(

                                            imageUrl: Uri.encodeFull(
                                                myOfferData[index]['images'][0]),height: 100,width: 90,
                                            fit: BoxFit.fill,
                                            placeholder:   CircularProgressIndicator(strokeWidth: 2,) ,
                                            errorWidget:   Icon(Icons.broken_image, size: 32,color: Colors.grey,),
                                          ),
                                        )




                                       /* child: FadeInImage.memoryNetwork(
                                          height: 90.0,
                                          placeholder: kTransparentImage,
                                          image: Uri.encodeFull(
                                              myOfferData[index]['images'][0]),
                                        ),*/


                                      ),
                                    ],
                                  ),
                                ),
                                Padding(
                                    padding: EdgeInsets.only(top: 0),
                                    child: Text(
                                      myOfferData[index]['heading'],
                                      style: TextStyle(
                                        color: Colors.blueAccent,
                                        fontSize: 15,
                                        fontFamily: 'Montserrat',
                                      ),
                                    )),
                                Padding(
                                    padding: EdgeInsets.only(top: 2),
                                    child: Text(
                                      myOfferData[index]['description'],
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                          color: Colors.black54,
                                          fontFamily: 'Montserrat',
                                          fontSize: 12),
                                      maxLines: 2,
                                      overflow: TextOverflow.ellipsis,
                                    )),
                                Padding(
                                    padding: EdgeInsets.only(top: 3),
                                    child: Text(
                                      myOfferData[index]['offer_start_date'] +
                                          " to " +
                                          myOfferData[index]['offer_last_date'],
                                      style: TextStyle(
                                          color: Colors.black54,
                                          fontFamily: 'Montserrat',
                                          fontSize: 11),
                                    )),
                                Padding(
                                    padding: EdgeInsets.only(top: 5),
                                    child: Row(
                                      mainAxisAlignment:
                                      MainAxisAlignment.spaceEvenly,
                                      crossAxisAlignment:
                                      CrossAxisAlignment.center,
                                      children: <Widget>[
                                        Text(
                                          "$quantity: " +
                                              myOfferData[index]['quantity'],
                                          style: TextStyle(
                                            color: Colors.blueAccent,
                                            fontFamily: 'Montserrat',
                                          ),
                                        ),
                                        Text(
                                          "AED. " +
                                              myOfferData[index]['special_price'],
                                          style: TextStyle(
                                            color: Colors.blueAccent,
                                            fontFamily: 'Montserrat',
                                          ),
                                        )
                                      ],
                                    )),
                                Padding(
                                    padding: EdgeInsets.only(top: 5),
                                    child: RaisedButton(
                                      onPressed: () {

                                        bookOffer(myOfferData[index]['id']);





                                      },
                                      child: Text(
                                        "$bookNow",
                                        style: TextStyle(
                                          color: Colors.white,
                                          fontFamily: 'Montserrat',
                                        ),
                                      ),
                                      splashColor: Colors.white,
                                      color: Colors.blue,
                                    )),
                              ],
                            ),
                          ))),
                ),
              );
            },
          ),
        ),

      ],
    )
    );
  }

  @override
  void initState() {
    super.initState();
    _chkLang();
    isLoading = true;
    getPrefData().then(getLogState);
    getOffers();
  }

  @override
  void dispose() {
    super.dispose();
    loading = false;


  }

  Future<String> getPrefData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String userID = prefs.getString("userID");

    return userID;
  }

  void getLogState(String userID) {
    if(loading ==true){
      setState(() {
        print("ShareeVAla" + userID);

        this.userID = userID;
      });
    }

  }

  Future<String> getOffers() async {
    final url = Apis.myOffers;
    SharedPreferences prefs = await SharedPreferences.getInstance();

    var response = await http.post(Uri.encodeFull(url), headers: {
      "Accept": "application/json"
    }, body: {
      "user_id": userID,
      "language":  prefs.getString("language"),
      "secret_hash": "W9zUnkWf5wJS27Yb2Nmmz3T"
    });
    setState(() {
      isLoading = false;
    });

    if (response.statusCode == 200) {
      if (loading == true) {
        setState(() {
          Map<String, dynamic> myOffersData = jsonDecode(response.body);



          myOfferData = myOffersData['Offers'];
        });
      }
    } else {}

    return "Sucess!";
  }


  Future<String> bookOffer(String id) async {
    final url = Apis.bookOffer;


    var response = await http.post(Uri.encodeFull(url), headers: {
      "Accept": "application/json"
    }, body: {
      "user_id": userID,
      "offer_id": id,
      "order_place": "tru",
      "latitude": "0.0",
      "longitude": "0.0",
      "secret_hash": "W9zUnkWf5wJS27Yb2Nmmz3T"
    });
    setState(() {
      isLoading = false;
    });

    if (response.statusCode == 200) {
      if (loading == true) {
        setState(() {

          Map<String, dynamic> myOffersData = jsonDecode(response.body);
         /* Fluttertoast.instance.showToast(
              msg: myOffersData['Response']['message'],
              toastLength: Toast.LENGTH_SHORT,
              gravity: ToastGravity.BOTTOM,
              timeInSecForIos: 1,
              backgroundColor: Colors.red,
              textColor: Colors.white);
*/





          //  print("ProooductOBj" + response.body);

        //  myOfferData = myOffersData['Offers'];
        });
      }
    } else {}

    return "Sucess!";
  }

    _chkLang() async {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      if(prefs.getString("language") == "a"){
        to ="إلى";
        bookNow = "الحجز";
        quantity = "الجودة";
        noOffers = "لم يتم العثور على عروض";
      }else{
        to ="to";
        bookNow = "Book Now";
        quantity = "Quantity";
        noOffers = "No offers found";
      }


  }





}
