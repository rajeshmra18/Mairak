/*
 * Created by Aravind on 1/24/19 3:00 PM
 * Copyright (c) 2019 . All rights reserved.
 *  Last modified 1/24/19 3:00 PM
 */

import 'dart:convert';

import 'package:mairak_final/allapi.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'package:shimmer/shimmer.dart';

class Notifications extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return NotificationsState();
  }
}


class NotificationsState extends State<Notifications> {
  List notificationLists;
  String userID = "";
  bool isLoading = true;
  int taxValue = 5;
  bool loading = true;
  String noNotify = "لا يوجد إشعارات – لا إخطا ";



  _chkLang() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    if(prefs.getString("language") == "a"){
      noNotify = "لا يوجد إشعارات – لا إخطا ";
    }else{
      noNotify = "No Notifications";
    }


  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Stack(children: <Widget>[
      Center(
        child: isLoading
            ?

        SizedBox(
          child: Shimmer.fromColors(
            baseColor: Colors.black12,
            highlightColor: Colors.white,
            child:

            Image.asset("images/shimmer.png",fit: BoxFit.fill,),
            /*  Text(
              'Loading',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 20.0,
                fontWeight:
                FontWeight.bold,
              ),
            ),*/
          ),
        )

    /*    Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  CircularProgressIndicator(),
                  Padding(
                    padding: const EdgeInsets.all(15.0),
                    child: Text("Loading"),
                  )
                ],
              )*/


            : notificationLists == null
                ? Center(
                    child: Text("$noNotify"),
                  )
                : ListView.builder(
                    itemCount: notificationLists == null
                        ? 0
                        : notificationLists.length,
                    itemBuilder: (BuildContext context, int index) {
                      return Container(
                        height: 70.0,
                        child:
                        notificationLists[index]['read_status']=='1'?
                        Card(
                          //color: Colors.black87,
                          color: Colors.black54,
                          child: Container(
                              child: Padding(
                                padding: EdgeInsets.only(left: 10, right: 15),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: <Widget>[
                                    Padding(
                                        padding:
                                        EdgeInsets.only(left: 10, right: 0),
                                        child: Container(

                                          /*   decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        color: Colors.redAccent),*/
                                            child: Center(
                                              child: Text(
                                                notificationLists[index]['title'],
                                                style: TextStyle(
                                                    color: Colors.white,
                                                    fontFamily: 'Montserrat'),
                                                textAlign: TextAlign.center,
                                              ),
                                            ))),
                                    Row(
                                      children: <Widget>[
                                        GestureDetector(
                                          child: Icon(
                                            Icons.open_in_new,
                                            color: Colors.white,
                                          ),
                                          onTap: () {
                                            _showDetails(index);
                                          },
                                        ),
                                        SizedBox(
                                          width: 30,
                                        ),
                                        GestureDetector(
                                          child: Icon(
                                            Icons.close,
                                            color: Colors.white,
                                          ),
                                          onTap: () {
                                            _deleteNotifications(index);
                                          },
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              )),
                        )
                            :


                        Card(
                          //color: Colors.black87,
                          color: Colors.black87,
                          child: Container(
                              child: Padding(
                            padding: EdgeInsets.only(left: 10, right: 15),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: <Widget>[
                                Padding(
                                    padding:
                                        EdgeInsets.only(left: 10, right: 0),
                                    child: Container(

                                        /*   decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        color: Colors.redAccent),*/
                                        child: Center(
                                      child: Text(
                                        notificationLists[index]['title'],
                                        style: TextStyle(
                                            color: Colors.white,
                                            fontFamily: 'Montserrat'),
                                        textAlign: TextAlign.center,
                                      ),
                                    ))),
                                Row(
                                  children: <Widget>[
                                    GestureDetector(
                                      child: Icon(
                                        Icons.open_in_new,
                                        color: Colors.white,
                                      ),
                                      onTap: () {
                                        _readNotification(index);
                                        _showDetails(index);
                                      },
                                    ),
                                    SizedBox(
                                      width: 30,
                                    ),
                                    GestureDetector(
                                      child: Icon(
                                        Icons.close,
                                        color: Colors.white,
                                      ),
                                      onTap: () {
                                        _deleteNotifications(index);
                                      },
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          )),
                        ),
                      );
                    },
                  ),
      ),
    ]));
  }

  @override
  void initState() {
    super.initState();
    _chkLang();
    isLoading = true;
    getSharedData();
    Future.delayed(Duration(seconds: 5));
  }

  getSharedData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      userID = prefs.getString("userID");
      getNotifications();
    });
  }

  Future<String> getNotifications() async {
    final url = Apis.getNotifications;
    print(userID);
    String uID = userID;
    var response = await http.post(Uri.encodeFull(url),
        headers: {"Accept": "application/json"},
        body: {"userid": uID, "secret_hash": "W9zUnkWf5wJS27Yb2Nmmz3T"});
    print(userID);
    setState(() {
      isLoading = false;
    });

    print(response.body);
    if (response.statusCode == 200) {
      if (loading == true) {
        setState(() {
          Map<String, dynamic> notifi = jsonDecode(response.body);
          print(response.body);
          notificationLists = notifi['Notification'];
        });
      }
    } else {}

    return "Sucess!";
  }

   _showDetails(int index) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return CupertinoAlertDialog(
          title:   Text(notificationLists[index]['title']),
          content:   Text(notificationLists[index]['message']),
          actions: <Widget>[
            CupertinoDialogAction(
                child: const Text('Remove'),
                isDestructiveAction: true,
                onPressed: () {
                  Navigator.pop(context, 'Remove');
                  _deleteNotifications(index);
                }),
              CupertinoDialogAction(
                child: const Text('Close'),
                isDefaultAction: true,
                onPressed: () {
                  getNotifications();
                  Navigator.pop(context, 'Close');
                }),
          ],
        );
      },
      barrierDismissible: false,
    );
  }

  Future<String> _deleteNotifications(int index) async {
    final url = Apis.delNotifications;
    print(userID);
    String uID = userID;
    var response = await http.post(Uri.encodeFull(url), headers: {
      "Accept": "application/json"
    }, body: {
      "userid": uID,
      "notification_id": notificationLists[index]['id']
    });
    print(userID);
    setState(() {
      isLoading = false;
    });

    if (response.statusCode == 200) {
      if (loading == true) {
        getNotifications();
      }
    } else {}

    return "Sucess!";
  }

  Future<String> _readNotification(int index) async {
    final url = Apis.readNotifications;
    var response = await http.post(Uri.encodeFull(url), headers: {
      "Accept": "application/json"
    }, body: {
      "userid": userID,
      "read_status": "1",
      "notification_id": notificationLists[index]['id']
    });

    print("reaaaaaaaaa"+response.body);

    if(response.statusCode==200){
     // getNotifications();
      return "Sucess!";
    }else{
      return "Failed";
    }


  }


}


