import 'package:mairak_final/address_selection.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
/**
 * Created by Aravind on 1/9/19 5:07 PM
 * Copyright (c) 2019 . All rights reserved.
 *  Last modified 1/9/19 5:07 PM
 */

import 'package:flutter/material.dart';
//import 'package:geocoder/geocoder.dart';
//import 'package:geocoder/model.dart';
import 'package:geolocator/geolocator.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:shimmer/shimmer.dart';
import 'widgets.dart';
import 'dart:convert';
import 'package:mairak_final/allapi.dart';

//import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;

//import 'package:device_id/device_id.dart';
import 'package:flutter/services.dart';

final _formKey = GlobalKey<FormState>();
final _promoCtrl = TextEditingController();
int _selectedIndex = -1;

class CartPage extends StatefulWidget {
  final Function getBadge;

  CartPage(this.getBadge);

  @override
  _CartPageState createState() => new _CartPageState();
}

class _CartPageState extends State<CartPage> {
  String userID;

  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  bool isLoading = true;
  List cartItems;
  int totalCount = 0;
  double totalAmount = 0;
  String lat = "0.0", lon = "0.0";
  String _deviceId = 'Unknown';
  String quantity = "Quantity",
      remove = "Remove",
      number = "Number",
      havePromo = "Have a Promo Code? Apply",
      totalInc = "Total inc 5% tax",
      book = "Book",
      mairak = "";

  // List<String> promoCodes = <String>['Belgium','France','Italy','Germany','Spain','Portugal'];
  List promoCodes;

  String taxVal;

  _chkLang() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    if (prefs.getString("language") == "a") {
      quantity = "الجودة";
      remove = "إزالة";
      number = "إرقام – إعداد ";
      havePromo = "أمتلك الرمز الترويجي تطبق ";
      totalInc = " المجموع  الموئمر الوطني  5% ضريبة ";
      book = "الحجز";
      mairak = "مايرك";
    } else {
      quantity = "Quantity";
      remove = "Remove";
      number = "Number";
      havePromo = "Have a Promo Code? Apply";
      totalInc = "Total inc $taxVal% tax";
      book = "Book";
      mairak = "Mai Rak";
    }
  }

  Future<void> initDeviceId() async {
    String deviceId;

   // deviceId = await DeviceId.getID;

    if (!mounted) return;

    print("vhdsvfdhsfgvjdfbgvkdbvjfb :::::: " + deviceId);

    setState(() {
      _deviceId = deviceId;
    });
  }

  @override
  Widget build(BuildContext context) {
    /*  double mWidth = MediaQuery.of(context).size.width;
    double mHeight = MediaQuery.of(context).size.height;*/

    return Scaffold(
      key: _scaffoldKey,
      resizeToAvoidBottomPadding: false,
      appBar: AppBar(
        title: Text(
          "$mairak",
          style: TextStyle(
              color: Colors.white, fontFamily: 'Montserrat', fontSize: 22),
        ),
        centerTitle: true,
      ),
      body: Container(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.end,
          children: <Widget>[
            Expanded(
              child: Container(
                  height: 400,
                  child: Stack(
                    children: <Widget>[
                      Center(
                        child: isLoading
                            ? SizedBox(
                                child: Shimmer.fromColors(
                                  baseColor: Colors.black12,
                                  highlightColor: Colors.white,
                                  child: Image.asset(
                                    "images/shimmer.png",
                                    fit: BoxFit.cover,
                                  ),
                                  /*  Text(
              'Loading',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 20.0,
                fontWeight:
                FontWeight.bold,
              ),
            ),*/
                                ),
                              )

                            /*  Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: <Widget>[
                                  CircularProgressIndicator(),
                                  Padding(
                                    padding: const EdgeInsets.all(15.0),
                                    child: Text("Loading"),
                                  )
                                ],
                              )
                        */

                            : Container(),
                      ),
                      ListView.builder(
                        itemCount: cartItems == null ? 0 : cartItems.length,
                        itemBuilder: (BuildContext context, int index) {
                          return Container(
                            height: 170.0,
                            child: Card(
                              child: Container(
                                  child: Padding(
                                      padding:
                                          EdgeInsets.only(left: 10, right: 15),
                                      child: GestureDetector(
                                        child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceEvenly,
                                          crossAxisAlignment:
                                              CrossAxisAlignment.center,
                                          children: <Widget>[
                                            Padding(
                                                padding:
                                                    EdgeInsets.only(top: 0),
                                                child: Container(
                                                  width: 90,
                                                  child: Stack(
                                                    children: <Widget>[
                                                      Center(
                                                          child: Container(
                                                        height: 80.0,
                                                        child:
                                                            CachedNetworkImage(
                                                          fit: BoxFit.fill,
                                                          imageUrl:
                                                              Uri.encodeFull(
                                                                  cartItems[
                                                                          index]
                                                                      [
                                                                      'p_image']),
                                                          placeholder:
                                                              CircularProgressIndicator(
                                                            strokeWidth: 2,
                                                          ),
                                                          height: 100,
                                                          width: 90,
                                                          errorWidget: Icon(
                                                            Icons.broken_image,
                                                            size: 32,
                                                            color: Colors.grey,
                                                          ),
                                                        ),
                                                      )

                                                          /*    child: FadeInImage
                                                            .memoryNetwork(
                                                          //height: 90.0,
                                                          placeholder:
                                                              kTransparentImage,
                                                          image: Uri.encodeFull(
                                                              cartItems[index]
                                                                  ['p_image']),
                                                        ),*/
                                                          ),
                                                    ],
                                                  ),
                                                )),
                                            Column(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              children: <Widget>[
                                                Padding(
                                                    padding:
                                                        EdgeInsets.only(top: 0),
                                                    child: Text(
                                                      cartItems[index]
                                                          ['p_name'],
                                                      style: TextStyle(
                                                        color:
                                                            Colors.blueAccent,
                                                        fontSize: 17,
                                                        fontFamily:
                                                            'Montserrat',
                                                      ),
                                                    )),
                                                Padding(
                                                    padding:
                                                        EdgeInsets.only(top: 2),
                                                    child: Container(
                                                        width: 150,
                                                        child: Text(
                                                          cartItems[index]
                                                              ['p_desc'],
                                                          textAlign:
                                                              TextAlign.center,
                                                          style: TextStyle(
                                                              color: Colors
                                                                  .black54,
                                                              fontFamily:
                                                                  'Montserrat',
                                                              fontSize: 11),
                                                          maxLines: 3,
                                                          overflow: TextOverflow
                                                              .ellipsis,
                                                        ))),
                                                /* Padding(
                                                  padding:
                                                      EdgeInsets.only(top: 2),
                                                  child: Text(""),
                                                  //     Text( cartItems[index]['offer_start_date'] + " to " + cartItems[index]['offer_last_date'],style: TextStyle(color: Colors.black54,fontFamily: 'Montserrat',fontSize: 11),)
                                                ),*/
                                                Padding(
                                                    padding:
                                                        EdgeInsets.only(top: 2),
                                                    child: Row(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .spaceBetween,
                                                      children: <Widget>[
                                                        Text(
                                                          "$quantity: " +
                                                              cartItems[index]
                                                                  ['qnty'],
                                                          style: TextStyle(
                                                            color: Colors
                                                                .blueAccent,
                                                            fontFamily:
                                                                'Montserrat',
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 35,
                                                        ),
                                                        Text(
                                                          "AED. " +
                                                              double.parse(cartItems[
                                                                          index]
                                                                      ['price'])
                                                                  .toStringAsFixed(
                                                                      2),
                                                          style: TextStyle(
                                                            color: Colors
                                                                .blueAccent,
                                                            fontFamily:
                                                                'Montserrat',
                                                          ),
                                                        )
                                                      ],
                                                    )),
                                                Padding(
                                                    padding:
                                                        EdgeInsets.only(top: 0),
                                                    child: RaisedButton(
                                                      onPressed: () {
                                                        String id =
                                                            cartItems[index]
                                                                ['cart_id'];
                                                        deleteCart(id);
                                                      },
                                                      child:
                                                          //  Icon(Icons.delete_forever,color: Colors.white,),
                                                          Text(
                                                        "$remove",
                                                        style: TextStyle(
                                                          color: Colors.white,
                                                          fontFamily:
                                                              'Montserrat',
                                                        ),
                                                      ),
                                                      splashColor: Colors.white,
                                                      color: Colors.blue,
                                                    )),
                                              ],
                                            ),
                                          ],
                                        ),
                                      ))),
                            ),
                          );
                        },
                      ),
                    ],
                  )),
              flex: 2,
            ),
            Expanded(
              child: Container(
                  color: Colors.black54,
                  height: 159.0,
                  //height: mHeight*0.20,

                  child: Card(
                    elevation: 10,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        Padding(
                          padding: const EdgeInsets.only(top: 10),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: <Widget>[
                              Text(
                                // "Total inc $taxVal % Tax",
                                "$totalInc",
                                style: TextStyle(
                                    color: Colors.black87,
                                    fontFamily: 'Montserrat'),
                              ),
                              Text(
                                "$number",
                                style: TextStyle(
                                    color: Colors.black87,
                                    fontFamily: 'Montserrat'),
                              )
                            ],
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(top: 2),
                          child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              children: <Widget>[
                                Text(
                                  totalAmount.toStringAsFixed(2),
                                  style: TextStyle(
                                      color: Colors.black,
                                      fontFamily: 'Montserrat'),
                                ),
                                Text(
                                  totalCount.toString(),
                                  style: TextStyle(
                                      color: Colors.black,
                                      fontFamily: 'Montserrat'),
                                )
                              ]),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(top: 5),
                          child: FlatButton(
                              onPressed: () {
                                if (totalCount > 0) {
                                  showDialog(
                                    context: context,
                                    builder: (BuildContext context) {
                                      // return object of type Dialog
                                      return CupertinoAlertDialog(
                                        title: Text('Please select',
                                            style: TextStyle(
                                              fontFamily: 'Montserrat',
                                            )),
                                        actions: <Widget>[
                                          CupertinoDialogAction(
                                            isDestructiveAction: true,
                                            onPressed: () {
                                              Navigator.of(context)
                                                  .pop('Cancel');
                                            },
                                            child: new Text('Cancel',
                                                style: TextStyle(
                                                  fontFamily: 'Montserrat',
                                                )),
                                          ),
                                          CupertinoDialogAction(
                                            isDestructiveAction: true,
                                            onPressed: () {
                                              if (_selectedIndex == -1) {
                                                if (_formKey.currentState
                                                    .validate()) {
                                                  Navigator.of(context).pop();
                                                  _applyPromoCode(
                                                      _promoCtrl.text);
                                                }
                                              } else {
                                                Navigator.of(context).pop();
                                                _applyPromoCode(
                                                    promoCodes[_selectedIndex]);
                                              }
                                            },
                                            child: Text(
                                              'Apply',
                                              style: TextStyle(
                                                color: Colors.blue,
                                                fontFamily: 'Montserrat',
                                              ),
                                            ),
                                          ),
                                        ],
                                        content: SingleChildScrollView(
                                          child: Material(
                                            color: Colors.transparent,
                                            child: MyDialogContent(
                                                promoCodes: promoCodes),
                                          ),
                                        ),
                                      );

                                      /*  AlertDialog(
                                        title: Text(
                                          "Apply Promo Code",
                                          style: TextStyle(
                                              fontFamily: 'Montserrat'),
                                        ),
                                        content: Center(
                                          child: Column(
                                            children: <Widget>[
                                              Form(
                                                key: _formKey,
                                                child: TextFormField(
                                                  keyboardType:
                                                      TextInputType.text,
                                                  autofocus: false,
                                                  controller: _promoCtrl,
                                                  validator: (value) {
                                                    if (value.isEmpty) {
                                                      return 'Please enter promo code!';
                                                    }
                                                  },
                                                  style: TextStyle(
                                                      fontFamily: 'Montserrat',
                                                      color: Colors.black),
                                                  decoration: InputDecoration(
                                                    hintText:
                                                        'Enter Promo Code',
                                                    contentPadding:
                                                        EdgeInsets.fromLTRB(
                                                            20.0,
                                                            10.0,
                                                            20.0,
                                                            10.0),
                                                    // border: OutlineInputBorder(borderRadius: BorderRadius.circular(radius)),
                                                  ),
                                                ),
                                              ),
                                              promoCodes.length == 0
                                                  ? Container()
                                                  : Column(
                                                      children: List<
                                                              RadioListTile<
                                                                  int>>.generate(
                                                          promoCodes.length,
                                                          (int index) {
                                                      return RadioListTile<int>(
                                                        value: index,
                                                        groupValue:
                                                            _selectedIndex,
                                                        title: Text(
                                                            promoCodes[index]),
                                                        onChanged: (int value) {
                                                          setState(() {
                                                            _selectedIndex =
                                                                value;
                                                          });
                                                        },
                                                      );
                                                    })),
                                            ],
                                          ),
                                        ),
                                        actions: <Widget>[
                                          // usually buttons at the bottom of the dialog
                                          FlatButton(
                                            child: new Text(
                                              "Apply",
                                              style: TextStyle(
                                                  fontFamily: 'Montserrat'),
                                            ),
                                            onPressed: () {
                                              if (_selectedIndex == -1) {
                                                if (_formKey.currentState
                                                    .validate()) {
                                                  Navigator.of(context).pop();
                                                  _applyPromoCode(
                                                      _promoCtrl.text);
                                                }
                                              } else {
                                                Navigator.of(context).pop();
                                                _applyPromoCode(
                                                    promoCodes[_selectedIndex]);
                                              }
                                            },
                                          ),
                                          FlatButton(
                                            child: new Text(
                                              "Close",
                                              style: TextStyle(
                                                  fontFamily: 'Montserrat'),
                                            ),
                                            onPressed: () {
                                              Navigator.of(context).pop();
                                            },
                                          ),
                                        ],
                                      );*/
                                    },
                                  );
                                } else {
                                  _scaffoldKey.currentState.showSnackBar(SnackBar(
                                      content: Text(
                                          "Sorry! Can't apply to empty cart")));
                                }
                              },
                              child: Text(
                                "$havePromo",
                                style: TextStyle(
                                    color: Colors.lightBlue,
                                    fontFamily: 'Montserrat'),
                              )),
                        ),
                        Padding(
                          padding: EdgeInsets.only(top: 1),
                          child: Container(
                            width: 290,
                            child: RaisedButton(
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(24),
                              ),
                              onPressed: () {
//          Navigator.pushNamed(context,'/Home');
                                //   Navigator.of(context).pushNamed(Home.tag);

                                if (totalCount > 0) {
                                  Navigator.pushReplacement(
                                      context,
                                      new MaterialPageRoute(
                                          builder: (context) => AddressSel()));
                                } else {
                                  _scaffoldKey.currentState.showSnackBar(
                                      SnackBar(
                                          content: Text(
                                              "Sorry! Your Cart is Empty")));
                                }
                              },
                              padding: EdgeInsets.all(12),
                              // color: const Color(0xff07a7cf),

                              color: const Color(0xff1a606f),

                              child: Text('$book',
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontFamily: 'Montserrat')),
                            ),
                          ),
                        )
                      ],
                    ),
                  )),
              flex: 1,
            ),
          ],
        ),
      ),
    );
  }

  @override
  void initState() {
    super.initState();
    _chkLang();
    initDeviceId();
    _getGeoLocation();
    _getCartInfo();

    getCart();
  }

  Future<String> getCart() async {
    final url = Apis.cartList;
    SharedPreferences prefs = await SharedPreferences.getInstance();
    userID = prefs.getString("userID");
    var response = await http.post(Uri.encodeFull(url),
        headers: {"Accept": "application/json"},
        body: {"userid": userID, "language": prefs.getString("language")});
    setState(() {
      isLoading = false;
    });

    if (response.statusCode == 200) {
      totalAmount = 0;
      totalCount = 0;
      setState(() {
        Map<String, dynamic> myCart = jsonDecode(response.body);

        print("ProooductOBj" + response.body);

        cartItems = myCart['Cart'];

        if (myCart['Response']['status'] == 1) {
          for (var element in cartItems) {
            totalAmount = totalAmount +
                (double.parse(element['price']) *
                    double.parse(element['qnty']));
          }
          double taxVal = (totalAmount / 100) * 5;
          totalAmount = totalAmount + taxVal;
        } else {
          totalAmount = 0;
        }

        totalCount = myCart['Response']['total'];
        // print("CarrtttItemsss : " + cartItems.toString());
      });
    } else {
      print("Exxxxxxxxxxxc epppp");
    }

    return "Sucess!";
  }

  Future<String> deleteCart(String id) async {
    final url = Apis.deleteCart;

    var response = await http.post(Uri.encodeFull(url),
        headers: {"Accept": "application/json"},
        body: {"userid": userID, "cart_id": id, "": id});
    setState(() {
      isLoading = false;
    });

    if (response.statusCode == 200) {
      setState(() {
        Map<String, dynamic> delCart = jsonDecode(response.body);

        _scaffoldKey.currentState.showSnackBar(
            SnackBar(content: Text("${delCart['Response'][0][0]['message']}")));

        widget.getBadge();

        getCart();
      });
    } else {}

    return "Sucess!";
  }

  Future<void> _applyPromoCode(String proCode) async {
    final url = Apis.applyPromo;
    var imei = "e";
    //= await ImeiPlugin.getImei;
    var response = await http.post(Uri.encodeFull(url), headers: {
      "Accept": "application/json"
    }, body: {
      "user_id": userID,
      "ime_number": _deviceId,
      "promo_code": proCode,
      "longitude": lon,
      "latitude": lat,
    });

    if (response.statusCode == 200) {
      getCart();
    }
  }

  _getGeoLocation() async {
   /* try {
      var position = await Geolocator()
          .getLastKnownPosition(desiredAccuracy: LocationAccuracy.high);
      // print(position.latitude.toString() + " :::::::::::: " + position.longitude.toString()+ " ::::::::: " + position.altitude.toString());
      lat = position.latitude.toString();
      lon = position.longitude.toString();
      final coordinates = Coordinates(position.latitude, position.longitude);
      var addresses =
          await Geocoder.local.findAddressesFromCoordinates(coordinates);
      var first = addresses.first;
      print(
          "${first.featureName} : ${first.subLocality} : ${first.adminArea} : ${first.postalCode}");
    } on PlatformException {}*/
  }

  Future<void> _getCartInfo() async {
    final url = Apis.cartInfo;
    SharedPreferences prefs = await SharedPreferences.getInstance();
    userID = prefs.getString("userID");

    var response = await http.post(Uri.encodeFull(url), headers: {
      "Accept": "application/json"
    }, body: {
      "user_id": userID,
    });

    print(response.body);

    if (response.statusCode == 200) {
      Map<String, dynamic> cartData = jsonDecode(response.body);

      setState(() {
        if (cartData['Response']['data']['promocode'] == null) {
          promoCodes = [];
        } else {
          promoCodes = cartData['Response']['data']['promocode'];
        }

        taxVal = cartData['Response']['data']['web_settings']['tax'];
      });

      _chkLang();

      print(promoCodes);
    }

    _chkLang();
  }
}

class MyDialogContent extends StatefulWidget {
  MyDialogContent({
    Key key,
    this.promoCodes,
  }) : super(key: key);

  final List promoCodes;

  @override
  _MyDialogContentState createState() => new _MyDialogContentState();
}

class _MyDialogContentState extends State<MyDialogContent> {
  @override
  void initState() {
    super.initState();
  }

  _getContent() {
    if (widget.promoCodes.length == 0) {
      return new Container();
    }

    return Center(
      child: Column(
        children: <Widget>[
          Form(
            key: _formKey,
            child: TextFormField(
              keyboardType: TextInputType.text,
              autofocus: false,
              controller: _promoCtrl,
              validator: (value) {
                if (value.isEmpty) {
                  return 'Please enter promo code!';
                }
              },
              style: TextStyle(fontFamily: 'Montserrat', color: Colors.black),
              decoration: InputDecoration(
                hintText: 'Enter Promo Code',
                hintStyle: TextStyle(
                  fontFamily: 'Montserrat',
                ),
                contentPadding: EdgeInsets.fromLTRB(20.0, 10.0, 20.0, 10.0),
                // border: OutlineInputBorder(borderRadius: BorderRadius.circular(radius)),
              ),
            ),
          ),
          Column(
              children: List<RadioListTile<int>>.generate(
                  widget.promoCodes.length, (int index) {
            return RadioListTile<int>(
              value: index,
              groupValue: _selectedIndex,
              title: Text(widget.promoCodes[index],
                  style: TextStyle(
                    fontFamily: 'Montserrat',
                  )),
              onChanged: (int value) {
                setState(() {
                  _selectedIndex = value;
                });
              },
            );
          })),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return _getContent();
  }
}
