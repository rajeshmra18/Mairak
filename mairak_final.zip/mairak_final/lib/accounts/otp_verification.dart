/*
 * Created by Aravind on 1/24/19 11:22 AM
 * Copyright (c) 2019 . All rights reserved.
 *  Last modified 1/24/19 11:22 AM
 */

import 'dart:convert';

import 'package:mairak_final/allapi.dart';
import 'package:mairak_final/home.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  runApp(MaterialApp());
}

class Otp extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return OtpState();
  }

  final String number;

  Otp(this.number);
}

class OtpState extends State<Otp> {
  final otpController = TextEditingController();
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();

  @override
  void dispose() {
    super.dispose();
    otpController.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        key: _scaffoldKey,
        backgroundColor: Colors.transparent,
        body: Stack(
          children: <Widget>[
            Container(
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: AssetImage('images/login_bg.jpg'),
                  fit: BoxFit.cover,
                ),
              ),
            ),
            Center(
              child: ListView(
                shrinkWrap: true,
                padding: EdgeInsets.only(left: 24.0, right: 24.0),
                children: <Widget>[
                  Hero(
                    tag: 'hero',
                    child: CircleAvatar(
                      backgroundColor: Colors.transparent,
                      radius: 48.0,
                      child: Image.asset('images/logo_main.png'),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 32.0, bottom: 15.0),
                    child: Text(
                      'OTP Verification',
                      style: TextStyle(
                        color: const Color(0xff1a606f),
                        fontSize: 25.0,
                        fontFamily: 'Montserrat',
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                  SizedBox(height: 48.0),
                  TextFormField(
                    keyboardType: TextInputType.phone,
                    autofocus: false,
                    controller: otpController,
                    style: TextStyle(
                        fontFamily: 'Montserrat', color: Colors.black),
                    decoration: InputDecoration(
                      hintText: 'Phone Number',
                      hintStyle: TextStyle(
                        fontFamily: 'Montserrat',
                      ),
                      labelText: "OTP",
                      labelStyle: TextStyle(
                        fontFamily: 'Montserrat',
                      ),
                      hasFloatingPlaceholder: true,
                      prefixIcon: Icon(Icons.vpn_key),
                      contentPadding:
                          EdgeInsets.fromLTRB(1.0, 10.0, 20.0, 10.0),
                      // border: OutlineInputBorder(borderRadius: BorderRadius.circular(radius)),
                    ),
                  ),
                  SizedBox(height: 8.0),
                  Padding(
                    padding: EdgeInsets.symmetric(vertical: 16.0),
                    child: RaisedButton(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(24),
                      ),
                      onPressed: () {
                        callOtpVerification();
                      },
                      padding: EdgeInsets.all(12),
                      // color: const Color(0xff07a7cf),
                      color: const Color(0xff1a606f),

                      child: Text('Submit',
                          style: TextStyle(
                              color: Colors.white, fontFamily: 'Montserrat')),
                    ),
                  )
                ],
              ),
            ),
          ],
        ));
  }

  Future<String> callOtpVerification() async {
    final url = Apis.otpVerification;
    SharedPreferences prefs = await SharedPreferences.getInstance();

    var response = await http.post(Uri.encodeFull(url), headers: {
      "Accept": "application/json"
    }, body: {
      "otp": otpController.text.trim(),
      "phone_number": widget.number,
    });

    if (response.statusCode == 200) {
      Map<String, dynamic> user = jsonDecode(response.body);

      print("Otp " + response.body);

      if (user['Response']['status'] == 1) {
        String _userID = user['user_id'];
        String _refCode = user['ref_code'];
        String _appUrl = user['ref_url'];

        prefs.setString('loggedin', "y");
        prefs.setString('userID', _userID);
        prefs.setString('refCode', _refCode);
        prefs.setString('appUrl', _appUrl);

        Navigator.pushReplacement(
            context, new MaterialPageRoute(builder: (context) => Home()));
      } else {
        _scaffoldKey.currentState.showSnackBar(
            SnackBar(content: Text("${user['Response']['message']}")));
      }
    } else {
      throw Exception('Failed to load post');
    }

    return "Sucess!";
  }
}
