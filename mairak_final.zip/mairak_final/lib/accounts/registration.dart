import 'dart:convert';

import 'package:mairak_final/allapi.dart';
import 'package:mairak_final/accounts/otp_verification.dart';

/**
 * Created by Aravind on 1/11/19 11:50 AM
 * Copyright (c) 2019 . All rights reserved.
 *  Last modified 1/11/19 11:50 AM
 */

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'login.dart';
import 'package:geolocator/geolocator.dart';
//import 'package:geocoder/geocoder.dart';
import 'package:http/http.dart' as http;


void main() => runApp(Center());

class Registration extends StatefulWidget {
  @override
  _Registration createState() => _Registration();
}

class _Registration extends State<Registration> {
  bool isChecked = false;
  String register = "التسجيل";
  String fullName="",phoneNumber="",add1="",add2="",state="",pin="",areYou = "",alreadyHave ="";
  double lat = 0.0 ,lan = 0.0;
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();

  final position = Position;

  final nameCtrl = TextEditingController();
  final phoneCtrl = TextEditingController();
  final addrOCtrl = TextEditingController();
  final addrTCtrl = TextEditingController();
  final stateCtrl = TextEditingController();
  final pinCtrl = TextEditingController();
  final _formKey = GlobalKey<FormState>();


  @override
  void dispose() {
    super.dispose();
     nameCtrl.dispose();
     phoneCtrl.dispose();
     addrOCtrl.dispose();
     addrTCtrl.dispose();
     stateCtrl.dispose();
     pinCtrl.dispose();

  }



  chkLang() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    if(prefs.getString("language") == "a"){
      setState(() {

        register = "التسجيل";
        fullName="الاسم بالكامل";
        phoneNumber="رقم الهاتف";
        add1="العنوان (1)";
        add2="العنوان (2)";
        state="الدولة";
        pin="رمز";
        areYou = "هل أنت مشترك ؟";
        alreadyHave ="هل أنت مشترك ؟ الدخول";

      });


    }else {
      setState(() {
        register = "Register";
        fullName="Full Name";
        phoneNumber="Phone Number";
        add1="Address 1";
        add2="Address 2";
        state="State";
        pin="Pin";
        areYou = "Are you a Govt emplotee?";
        alreadyHave ="Already have an account? Login";

      });

    }
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);

    return Scaffold(
      key: _scaffoldKey,
      body: Stack(
        children: <Widget>[
          Container(
            decoration: BoxDecoration(
              image: DecorationImage(
                image: AssetImage('images/register_bg.jpg'),
                fit: BoxFit.cover,
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.only(top: 50),
            child: ListView(
              shrinkWrap: true,
              padding: EdgeInsets.only(left: 24.0, right: 24.0),
              children: <Widget>[
                Image.asset(
                  "images/logo_main.png",
                  height: 80,
                  width: 80,
                ),
                Padding(
                    padding: EdgeInsets.only(top: 15),
                    child: Text(
                      "$register",
                      style: TextStyle(
                          color: const Color(0xff1a606f),
                          fontFamily: 'Montserrat',
                          fontSize: 18),
                      textAlign: TextAlign.center,
                    )),
                SizedBox(height: 48.0),

                Form(key:_formKey,child:

                Column(

                  children: <Widget>[





                    Padding(
                      padding: EdgeInsets.only(top: 0),
                      child:TextFormField(
                        keyboardType: TextInputType.text,
                        autofocus: false,
                        validator: (value) {
                          if (value.isEmpty) {
                            return 'Please enter your name';
                          }
                        },
                        controller: nameCtrl,
                        style: TextStyle(
                            fontFamily: 'Montserrat', color: Colors.black87),
                        decoration: InputDecoration(
                          hintText: '$fullName',
                          contentPadding:
                          EdgeInsets.fromLTRB(3.0, 10.0, 20.0, 10.0),
                          // border: OutlineInputBorder(borderRadius: BorderRadius.circular(radius)),
                        ),
                      ),



                    ),


                    SizedBox(height: 5.0),
                    Padding(
                      padding: EdgeInsets.only(top: 5),
                      child: TextFormField(
                        keyboardType: TextInputType.number,
                        autofocus: false,
                        validator: (value) {
                          if (value.isEmpty) {
                            return 'Please enter a phone number';
                          }
                        },
                        controller: phoneCtrl,
                        style: TextStyle(
                            fontFamily: 'Montserrat', color: Colors.black87),
                        decoration: InputDecoration(
                          hintText: '$phoneNumber',
                          contentPadding: EdgeInsets.fromLTRB(3.0, 10.0, 20.0,
                              10.0), // border: OutlineInputBorder(borderRadius: BorderRadius.circular(radius)),
                        ),
                      ),
                    ),
                    SizedBox(height: 5.0),
                    Padding(
                      padding: const EdgeInsets.only(top: 0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: <Widget>[
                          Flexible(
                            child: TextFormField(
                              keyboardType: TextInputType.number,
                              controller: addrOCtrl,
                              autofocus: false,
                              validator: (value) {
                                if (value.isEmpty) {
                                  return 'Please enter a address';
                                }
                              },
                              style: TextStyle(
                                  fontFamily: 'Montserrat', color: Colors.black87),
                              decoration: InputDecoration(
                                hintText: '$add1',
                                contentPadding: EdgeInsets.fromLTRB(3.0, 10.0, 20.0,
                                    10.0), // border: OutlineInputBorder(borderRadius: BorderRadius.circular(radius)),
                              ),
                            ),
                            flex: 3,
                          ),
                          Flexible(
                            child: FlatButton(
                              child: Image.asset(
                                "images/pin1.png",
                                height: 40,
                                width: 40,
                              ),
                              onPressed: () {

                                getGeoLocation();





                              },
                            ),
                            flex: 1,
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(top: 5),
                      child: TextFormField(
                        keyboardType: TextInputType.number,
                        autofocus: false,
                        validator: (value) {
                          if (value.isEmpty) {
                            return 'Please enter a address';
                          }
                        },
                        controller: addrTCtrl,
                        style: TextStyle(
                            fontFamily: 'Montserrat', color: Colors.black87),
                        decoration: InputDecoration(
                          hintText: '$add2',
                          contentPadding:
                          EdgeInsets.fromLTRB(3.0, 10.0, 20.0, 10.0),
                          // border: OutlineInputBorder(borderRadius: BorderRadius.circular(radius)),
                        ),
                      ),
                    ),
                    Row(
                      children: <Widget>[
                        Flexible(
                          child: Padding(
                            padding: const EdgeInsets.only(right: 5),
                            child: TextFormField(
                              keyboardType: TextInputType.number,
                              autofocus: false,
                              validator: (value) {
                                if (value.isEmpty) {
                                  return 'Please enter a state';
                                }
                              },
                              controller: stateCtrl,
                              style: TextStyle(
                                  fontFamily: 'Montserrat', color: Colors.black87),
                              decoration: InputDecoration(
                                hintText: '$state',
                                contentPadding:
                                EdgeInsets.fromLTRB(3.0, 10.0, 20.0, 10.0),
                                // border: OutlineInputBorder(borderRadius: BorderRadius.circular(radius)),
                              ),
                            ),
                          ),
                          flex: 1,
                        ),
                        Flexible(
                          child: Padding(
                            padding: const EdgeInsets.only(left: 5),
                            child: TextFormField(
                              keyboardType: TextInputType.number,
                              autofocus: false,
                              controller: pinCtrl,
                              style: TextStyle(
                                  fontFamily: 'Montserrat', color: Colors.black87),
                              decoration: InputDecoration(
                                hintText: '$pin',
                                contentPadding:
                                EdgeInsets.fromLTRB(3.0, 10.0, 20.0, 10.0),
                                // border: OutlineInputBorder(borderRadius: BorderRadius.circular(radius)),
                              ),
                            ),
                          ),
                          flex: 1,
                        ),
                      ],
                    ),














                  ],







                )



                ),



                Padding(
                  padding: const EdgeInsets.only(top: 15),
                  child: Row(
                    children: <Widget>[
                      Checkbox(
                        value: isChecked,
                        onChanged: (bool value) {
                          setState(() {
                            isChecked = value;
                            print("chkVal" + isChecked.toString());
                          });
                        },
                      ),
                      Text("$areYou",
                          style: TextStyle(
                              fontFamily: 'Montserrat', color: Colors.black54))
                    ],
                  ),
                ),
                Padding(
                  padding: EdgeInsets.only(top: 15),
                  child: RaisedButton(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(24),
                    ),
                    onPressed: () {

                      if (_formKey.currentState.validate()) {

                        showDialog<void>(
                          context: context,
                          barrierDismissible: false,
                          // user must tap button!
                          builder: (BuildContext context) {
                            return

                            Center(
                              child: Container(
                                height: 180,
                                child:   AlertDialog(
                                  content: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: <Widget>[
                                      SizedBox(height: 15,),
                                      CircularProgressIndicator(),
                                      Padding(
                                        padding: const EdgeInsets.all(5.0),
                                      )
                                    ],
                                  ),
                                )



                              ),




                            );




                          },
                        );

                        callRegistration();

                      }

                      /*  Navigator.pushReplacement(context, new MaterialPageRoute(
                              builder: (context) =>
                              new Home())
                          );*/
                    },
                    padding: EdgeInsets.all(12),
                    // color: const Color(0xff07a7cf),
                    color: const Color(0xff1a606f),

                    child: Text('$register',
                        style: TextStyle(
                            color: Colors.white, fontFamily: 'Montserrat')),
                  ),
                ),
                Padding(
                    padding: EdgeInsets.only(top: 15),
                    child: FlatButton(
                      child: Text("$alreadyHave",
                          style: TextStyle(
                              fontSize: 12,
                              color: Colors.blue,
                              fontFamily: 'Montserrat')),
                      onPressed: () {
                        Navigator.pushReplacement(
                            context,
                            new MaterialPageRoute(
                                builder: (context) => new LoginPage()));
                      },
                    ))
              ],
            ),
          )
        ],
      ),
    );
  }


  @override
  void initState() {
    super.initState();
    chkLang();
    getLatLong();
  }

  getGeoLocation() async {
/*
      try {
        var position = await Geolocator().getLastKnownPosition(
            desiredAccuracy: LocationAccuracy.high);
       // print(position.latitude.toString() + " :::::::::::: " + position.longitude.toString()+ " ::::::::: " + position.altitude.toString());
        final coordinates = new Coordinates(position.latitude, position.longitude);
        var addresses = await Geocoder.local.findAddressesFromCoordinates(coordinates);
        var first = addresses.first;
       // print("${first.featureName} : ${first.subLocality} : ${first.adminArea} : ${first.postalCode}");

        setState(() {

          addrOCtrl.text = first.featureName.toString().trim();
          addrTCtrl.text = first.subLocality.toString().trim();
          stateCtrl.text = first.adminArea.toString().trim();
          pinCtrl.text = first.postalCode.toString().trim();


        });
      }on PlatformException {
*//*
        Fluttertoast.instance.showToast(
            msg: "Something went wrong please try again in a bit",
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.BOTTOM,
            timeInSecForIos: 1,
            backgroundColor: Colors.red,
            textColor: Colors.white);*//*

      }*/



   
  }



  Future<String> callRegistration() async {
    final url = Apis.registerUser;

    SharedPreferences prefs = await SharedPreferences.getInstance();

    String emp ;
    if(isChecked == true){
      emp = "yes";
    }else{
      emp = "no";
    }

    var response = await http.post(Uri.encodeFull(url), headers: {
      "Accept": "application/json"
    }, body: {
      "full_name": nameCtrl.text.trim(),
      "phone_number": phoneCtrl.text.trim(),
      "address_one": addrOCtrl.text.trim(),
      "address_two": addrTCtrl.text.trim(),
      "state": stateCtrl.text.trim(),
      "pincode": pinCtrl.text.trim(),
      "password": "",
      "repassword": "",
      "latitude": lat.toString(),
      "longitude": lan.toString(),
      "is_govtemployee":  emp,

    });

    Navigator.of(context).pop('Cancel');

    if (response.statusCode == 200) {
      Map<String, dynamic> user = jsonDecode(response.body);


      print("Registerr " + response.body);

      if (user['Response']['status'] == 1){


        if(prefs.getString("language") == null){
          prefs.setString('language', "e");
        }
        Navigator.pushReplacement(
            context, new MaterialPageRoute(builder: (context) =>   Otp(phoneCtrl.text.trim())));
      }else{
        _scaffoldKey.currentState.showSnackBar(
            SnackBar(content: Text("${user['Response']['message']}")));
      }




    } else {
      throw Exception('Failed to load post');
    }

    return "Sucess!";
  }

   getLatLong() async {

     try {
       var position = await Geolocator().getLastKnownPosition(
           desiredAccuracy: LocationAccuracy.high);
       print(position.latitude.toString() + " :::::::::::: " + position.longitude.toString()+ " ::::::::: " + position.altitude.toString());
       lat  = position.latitude;
       lan  = position.longitude;

       setState(() {



       });
     }on PlatformException {

      print("exception");

     }



   }


}
