/*
 * Created by Aravind on 1/11/19 12:37 PM
 * Copyright (c) 2019 . All rights reserved.
 *  Last modified 1/9/19 2:41 PM
 */

import 'package:flutter/material.dart';
import 'package:mairak_final/home.dart';
import 'package:flutter/services.dart';
import 'package:mairak_final/allapi.dart';
import 'registration.dart';
import 'dart:async';
import 'package:http/http.dart' as http;
import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';



class LoginPage extends StatefulWidget {
  static String tag = 'login-page';

  @override
  _LoginPageState createState() =>  _LoginPageState();
}


class _LoginPageState extends State<LoginPage> {
  final pNController = TextEditingController();
  final pWController = TextEditingController();
  final GlobalKey<ScaffoldState> _scaffoldKey =  GlobalKey<ScaffoldState>();

  String phoneNumber="",
      passwordT="",logHead="",
      newHere="",
      forgotPass="";

  @override
  void dispose() {
    pNController.dispose();
    pWController.dispose();
    super.dispose();
  }




  chkLang() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    if(prefs.getString("language") == "a"){


      setState(() {
        phoneNumber="رقم الهاتف";
        passwordT="رقم المرور";
        logHead="الدخول";
        newHere="جديد هنا? اشترك الآن";
        forgotPass="هل نسيت كلمة السر ؟";
      });




    }else {
     setState(() {

       phoneNumber="Phone Number";
       passwordT="Password";
       logHead="Login";
       newHere="New Here? Join Now";
       forgotPass="Forgot Password?";

     });

    }
  }


  @override
  void initState() {
    super.initState();
    chkLang();
  }

  @override
  Widget build(BuildContext context) {
    final logo = Hero(
      tag: 'hero',
      child: CircleAvatar(
        backgroundColor: Colors.transparent,
        radius: 48.0,
        child: Image.asset('images/logo_main.png'),
      ),
    );

    final email = TextFormField(
      keyboardType: TextInputType.phone,
      autofocus: false,
      controller: pNController,
      style: TextStyle(fontFamily: 'Montserrat', color: Colors.black),
      decoration: InputDecoration(
        hintText: '$phoneNumber',
        hintStyle: TextStyle(
          fontFamily: 'Montserrat',
        ),
        labelText: "$phoneNumber",
        labelStyle: TextStyle(
          fontFamily: 'Montserrat',
        ),
        hasFloatingPlaceholder: true,
        prefixIcon: Icon(Icons.phone),
        contentPadding: EdgeInsets.fromLTRB(1.0, 10.0, 20.0, 10.0),
        // border: OutlineInputBorder(borderRadius: BorderRadius.circular(radius)),
      ),
    );

    final password = TextFormField(
      autovalidate: true,
      autofocus: false,
      keyboardType: TextInputType.number,
      controller: pWController,
      obscureText: true,
      style: TextStyle(fontFamily: 'Montserrat', color: Colors.black),
      decoration: InputDecoration(
        hintText: '$passwordT',
        hintStyle: TextStyle(
          fontFamily: 'Montserrat',
        ),
        hasFloatingPlaceholder: true,
        labelText: "$passwordT",
        labelStyle: TextStyle(
          fontFamily: 'Montserrat',
        ),
        prefixIcon: Icon(Icons.lock),
        contentPadding: EdgeInsets.fromLTRB(20.0, 10.0, 20.0, 10.0),
      ),
    );

    final loginButton = Padding(
      padding: EdgeInsets.symmetric(vertical: 16.0),
      child: RaisedButton(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(24),
        ),
        onPressed: () {

       /*   Navigator.pushReplacement(
              context, new MaterialPageRoute(builder: (context) => new Home()));
*/


          if (pWController.text != "" && pNController != "") {
            _callLogin();
          } else {
            _showDialog();
          }
        },
        padding: EdgeInsets.all(12),
        // color: const Color(0xff07a7cf),
        color: const Color(0xff1a606f),

        child: Text('$logHead',
            style: TextStyle(color: Colors.white, fontFamily: 'Montserrat')),
      ),
    );

    final forgotLabel = FlatButton(
      child: Text(
        '$forgotPass',
        style: TextStyle(
            color: Colors.black54, fontFamily: 'Montserrat', fontSize: 12),
      ),
      onPressed: () {},
    );

    final registerButton = FlatButton(
      child: Text(
        '   $newHere',
        style: TextStyle(
            color: const Color(0xff07a7cf),
            fontFamily: 'Montserrat',
            fontSize: 12),
      ),
      onPressed: () {
        Navigator.push(context,
             MaterialPageRoute(builder: (context) =>   Registration()));
      },
    );

    final loginTitle = Column(
      children: <Widget>[
        Padding(
          padding: const EdgeInsets.only(top: 32.0, bottom: 15.0),
          child: Text(
            '$logHead',
            style: TextStyle(
              color: const Color(0xff1a606f),
              fontSize: 25.0,
              fontFamily: 'Montserrat',
            ),
            textAlign: TextAlign.center,
          ),
        ),
      ],
    );

    return Scaffold(
        key: _scaffoldKey,
        backgroundColor: Colors.transparent,
        body: Stack(
          children: <Widget>[
            Container(
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: AssetImage('images/login_bg.jpg'),
                  fit: BoxFit.cover,
                ),
              ),
            ),
            Center(
              child: ListView(
                shrinkWrap: true,
                padding: EdgeInsets.only(left: 24.0, right: 24.0),
                children: <Widget>[
                  logo,
                  loginTitle,
                  SizedBox(height: 48.0),
                  email,
                  SizedBox(height: 8.0),
                  password,
                  SizedBox(height: 24.0),
                  loginButton,
                  Padding(
                    padding: const EdgeInsets.only(top: 18),
                    child:  Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[forgotLabel, registerButton]),
                  )
                ],
              ),
            ),
          ],
        ));
  }

  Future<String> _callLogin() async {
    final url = Apis.loginApi;
    SharedPreferences prefs = await SharedPreferences.getInstance();

    var response = await http.post(Uri.encodeFull(url), headers: {
      "Accept": "application/json"
    }, body: {
      "phone_number": pNController.text.trim(),
      "password": pWController.text.trim()
    });


    print("rEEESSPPSPSPS" + response.body);

    if (response.statusCode == 200) {
      Map<String, dynamic> user = jsonDecode(response.body);

   //   LoginData loginData;

    //  loginData = LoginData.fromJson(json.decode(response.body));

   //   print(" vb fdhs   " + loginData.response.toString());

    //  print('Howdy, ${user['Response']['status']}!');

      if (user['Response']['status'] == 1) {
        String _userID = user['data']['user_id'];
        String _refCode = user['data']['ref_code'];
        String _appUrl = user['data']['ref_url'];

        prefs.setString('loggedin', "y");
        if(prefs.getString("language") == null){
          prefs.setString('language', "e");
        }
        prefs.setString('userID', _userID);
        prefs.setString('refCode', _refCode);
        prefs.setString('appUrl', _appUrl);




        Navigator.pushReplacement(
            context,  MaterialPageRoute(builder: (context) =>  Home()));
      } else {

        _scaffoldKey.currentState.showSnackBar( SnackBar(content:  Text("${user['Response']['message']}")));

     /*   Fluttertoast.instance.showToast(
            msg: "${user['Response']['message']}",
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.BOTTOM,
            timeInSecForIos: 1,
            backgroundColor: Colors.red,
            textColor: Colors.white);*/
      }
    } else {
      throw Exception('Failed to load post');
    }

    return "Sucess!";
  }

  void _showDialog() {
    // flutter defined function

    Future.delayed(Duration(milliseconds: 100)).then((_) {
      showDialog(
        context: context,
        builder: (BuildContext context) {
          // return object of type Dialog
          return AlertDialog(
            title: Text(
              "Alert !",
              style: TextStyle(
                  fontFamily: 'Montserrat', fontWeight: FontWeight.bold),
            ),
            content: Text(
              "Please fill your credentials",
              style: TextStyle(fontFamily: 'Montserrat'),
            ),
            actions: <Widget>[
              // usually buttons at the bottom of the dialog
              FlatButton(
                child: Text(
                  "Close",
                  style: TextStyle(fontFamily: 'Montserrat'),
                ),
                onPressed: () {
                  Navigator.of(context).pop();
                },
              ),
            ],
          );
        },
      );
    });
  }
}
