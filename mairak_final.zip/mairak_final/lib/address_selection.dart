/*
 * Created by Aravind on 1/28/19 12:29 PM
 * Copyright (c) 2019 . All rights reserved.
 *  Last modified 1/28/19 12:29 PM
 */


import 'package:mairak_final/thank_page.dart';
import 'package:mairak_final/widgets.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
//import 'package:geocoder/geocoder.dart';
import 'package:flutter/services.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:mairak_final/allapi.dart';

class AddressSel extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return AddressState();
  }
}

class AddressState extends State<AddressSel> {
  final addrOCtrl = TextEditingController();
  final nameCtrl = TextEditingController();
  final addrTCtrl = TextEditingController();
  final stateCtrl = TextEditingController();
  final pinCtrl = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  String lat = "0.0", lon = "0.0";
  String name = "", add1 = "", addr2 = "", stte = "";

  String tvName = "",tvAddr1 = "",tvAddr2 = "",tvState="",delToTHis = "",delToDef="",choose = "";
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();


  _chkLang() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    if (prefs.getString("language") == "a") {
      tvName = "الأسم ";
      tvAddr1 = " العنوان رقم 1 ";
      tvAddr2 = "العنوان رقم 2 ";
      tvState="ولاية ";
      delToTHis = "التوصيل الي هذا العنوان ";
      delToDef="التسليم إلي العنوان الافتراضي ";
      choose = "تحديد عنوان تسليم";
    } else {
      tvName = "Name";
      tvAddr1 = "Address 1";
      tvAddr2 = "Address 2";
      tvState="State";
      delToTHis = "Deliver To This Adress";
      delToDef="Deliver To Default Adress";
      choose = "Choose your Address";
    }
  }





  @override
  Widget build(BuildContext context) {
    return Scaffold(
        key: _scaffoldKey,
        resizeToAvoidBottomPadding: false,
        appBar: AppBar(
          title: ImageWidgets(),
          centerTitle: true,
        ),
        body: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.all(20.0),
              child: Text(
                "$choose",
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
            ),
            Container(
              height: 150,
              child: Padding(
                padding: EdgeInsets.only(top: 5, right: 5, left: 5),
                child: Card(
                  child: Padding(
                    padding: const EdgeInsets.only(top: 0),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Padding(
                          padding: const EdgeInsets.only(left: 35.0),
                          child: Row(
                            children: <Widget>[
                              Icon(Icons.location_on),
                              SizedBox(
                                width: 10,
                              ),
                              Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: <Widget>[
                                  Text("$name"),
                                  Text("$add1"),
                                  Text("$addr2"),
                                  Text("$stte"),
                                ],
                              ),
                            ],
                          ),
                        ),
                        Center(
                          child: Padding(
                            padding: EdgeInsets.only(top: 0),
                            child: Container(
                              width: 290,
                              child: RaisedButton(
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(24),
                                ),
                                onPressed: () {
                                  String addr = name + add1 + addr2 + stte;

                                  _prepareDefaultAddr(addr);
                                },
                                padding: EdgeInsets.all(0),
                                // color: const Color(0xff07a7cf),

                                color: const Color(0xff1a606f),

                                child: Text('$delToDef',
                                    style: TextStyle(
                                        color: Colors.white,
                                        fontFamily: 'Montserrat')),
                              ),
                            ),
                          ),
                        )
                      ],
                    ),
                  ),
                ),
              ),
            ),
            Container(
              height: (MediaQuery.of(context).size.height / 100) * 50,
              child: Padding(
                padding: EdgeInsets.only(top: 0, right: 5, left: 5),
                child: Card(
                  child: Padding(
                      padding: const EdgeInsets.only(top: 0),
                      child: Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          // crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Padding(
                              padding: const EdgeInsets.only(left: 35.0),
                              child: Row(
                                children: <Widget>[
                                  Icon(Icons.location_on),
                                  SizedBox(
                                    width: 10,
                                  ),
                                  Form(
                                    key: _formKey,
                                    child: Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: <Widget>[
                                        Container(
                                          width: 250,
                                          child: TextFormField(
                                            keyboardType: TextInputType.text,
                                            autofocus: false,
                                            controller: nameCtrl,
                                            validator: (value) {
                                              if (value.isEmpty) {
                                                return 'Please enter your name';
                                              }
                                            },
                                            style: TextStyle(
                                                fontFamily: 'Montserrat',
                                                color: Colors.black,
                                                fontSize: 12),
                                            decoration: InputDecoration(
                                              hintText: '$tvName',
                                              hintStyle: TextStyle(
                                                fontSize: 12,
                                                fontFamily: 'Montserrat',
                                              ),
                                            ),
                                          ),
                                        ),
                                        Container(
                                          width: 250,
                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceAround,
                                            children: <Widget>[
                                              Flexible(
                                                child: Padding(
                                                  padding:
                                                      EdgeInsets.only(left: 0),
                                                  child: TextFormField(
                                                    keyboardType:
                                                        TextInputType.number,
                                                    controller: addrOCtrl,
                                                    autofocus: false,
                                                    validator: (value) {
                                                      if (value.isEmpty) {
                                                        return 'Please enter a address';
                                                      }
                                                    },
                                                    style: TextStyle(
                                                        fontFamily:
                                                            'Montserrat',
                                                        color: Colors.black87,
                                                        fontSize: 12),
                                                    decoration: InputDecoration(
                                                      hintText: '$tvAddr1',

                                                      //   border: OutlineInputBorder(borderRadius: BorderRadius.circular(3)),
                                                    ),
                                                  ),
                                                ),
                                                flex: 3,
                                              ),
                                              Flexible(
                                                child: FlatButton(
                                                  child: Image.asset(
                                                    "images/pin1.png",
                                                    height: 40,
                                                    width: 40,
                                                  ),
                                                  onPressed: () {
                                                    getGeoLocation();
                                                  },
                                                ),
                                                flex: 1,
                                              ),
                                            ],
                                          ),
                                        ),
                                        Container(
                                          width: 250,
                                          child: TextFormField(
                                            keyboardType: TextInputType.phone,
                                            autofocus: false,
                                            controller: addrTCtrl,
                                            validator: (value) {
                                              if (value.isEmpty) {
                                                return 'Please enter a address';
                                              }
                                            },
                                            style: TextStyle(
                                                fontFamily: 'Montserrat',
                                                color: Colors.black,
                                                fontSize: 12),
                                            decoration: InputDecoration(
                                              hintText: '$tvAddr2',
                                              hintStyle: TextStyle(
                                                fontSize: 12,
                                                fontFamily: 'Montserrat',
                                              ),
                                            ),
                                          ),
                                        ),
                                        Container(
                                          width: 250,
                                          child: TextFormField(
                                            keyboardType: TextInputType.phone,
                                            autofocus: false,
                                            controller: stateCtrl,
                                            validator: (value) {
                                              if (value.isEmpty) {
                                                return 'Please enter your state';
                                              }
                                            },
                                            style: TextStyle(
                                                fontFamily: 'Montserrat',
                                                color: Colors.black,
                                                fontSize: 12),
                                            decoration: InputDecoration(
                                              hintText: '$tvState',
                                              hintStyle: TextStyle(
                                                fontFamily: 'Montserrat',
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Center(
                              child: Padding(
                                padding: EdgeInsets.only(top: 0),
                                child: Container(
                                  width: 290,
                                  child: RaisedButton(
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(24),
                                    ),
                                    onPressed: () {
                                      if (_formKey.currentState.validate()) {

                                        String addr = nameCtrl.text+addrOCtrl.text+addrTCtrl.text+stateCtrl.text;
                                        _prepareDefaultAddr(addr);

                                      }
                                    },
                                    padding: EdgeInsets.all(0),
                                    // color: const Color(0xff07a7cf),

                                    color: const Color(0xff1a606f),

                                    child: Text('$delToTHis',
                                        style: TextStyle(
                                            color: Colors.white,
                                            fontFamily: 'Montserrat')),
                                  ),
                                ),
                              ),
                            )
                          ],
                        ),
                      )),
                ),
              ),
            ),
          ],
        ));
  }

  getGeoLocation() async {
/*    try {
      var position = await Geolocator()
          .getLastKnownPosition(desiredAccuracy: LocationAccuracy.high);
      // print(position.latitude.toString() + " :::::::::::: " + position.longitude.toString()+ " ::::::::: " + position.altitude.toString());
      lat = position.latitude.toString();
      lon = position.longitude.toString();
      final coordinates =  Coordinates(position.latitude, position.longitude);
      var addresses = await Geocoder.local.findAddressesFromCoordinates(coordinates);
      var first = addresses.first;
      print(
          "${first.featureName} : ${first.subLocality} : ${first.adminArea} : ${first.postalCode}");

      setState(() {
        addrOCtrl.text = first.featureName.toString().trim();
        addrTCtrl.text = first.subLocality.toString().trim();
        stateCtrl.text = first.adminArea.toString().trim();
        pinCtrl.text = first.postalCode.toString().trim();
      });
    } on PlatformException {}*/
  }

  @override
  void initState() {
    super.initState();
    _chkLang();
    _getProfileData();
  }

  Future<void> _getProfileData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String userID = prefs.getString("userID");

    final url = Apis.myProfile;
    var response = await http.post(Uri.encodeFull(url),
        headers: {"Accept": "application/json"}, body: {"user_id": userID});

    print(response.body);

    if (response.statusCode == 200) {
      Map<String, dynamic> profile = jsonDecode(response.body);

      setState(() {
        name = profile['profile']['user_name'];
        add1 = profile['profile']['address_one'];
        addr2 = profile['profile']['address_two'];
        stte = profile['profile']['state'];
      });
    } else {}
  }

  Future<void> _prepareDefaultAddr(String addr) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String userID = prefs.getString("userID");

    final url = Apis.cartOrder;
    var response = await http.post(Uri.encodeFull(url), headers: {
      "Accept": "application/json"
    }, body: {
      "user_id": userID,
      "lat": lat,
      "lng": lon,
      "address": addr
    });

    print(response.body);

    if (response.statusCode == 200) {
      Map<String, dynamic> cartBuy = jsonDecode(response.body);

      if(cartBuy['Response']['status'] == 1){
        _scaffoldKey.currentState.showSnackBar(
            SnackBar(content: Text("${cartBuy['Response']['message']}")));

        Navigator.push(
            context,
            MaterialPageRoute(builder: (context) =>   ThankYou()));
      }else{

        _scaffoldKey.currentState.showSnackBar(
            SnackBar(content: Text("${cartBuy['Response']['message']}"),action: SnackBarAction(label: "Retry", onPressed: (){
              _prepareDefaultAddr(addr);
            }),));
      }


    }
  }
}
