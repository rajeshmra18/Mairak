/*
 * Created by Aravind on 1/18/19 1:35 PM
 * Copyright (c) 2019 . All rights reserved.
 *  Last modified 1/18/19 1:35 PM
 */

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:shimmer/shimmer.dart';
import 'allapi.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:async';

void main() => runApp(MaterialApp(
      home: OfferOrder(),
    ));

class OfferOrder extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return OfferOrderState();
  }
}

class OfferOrderState extends State<OfferOrder> {
  List offerOrdersData;
  String userID = "";
  bool isLoading = true;
  int taxValue = 5;
  bool loading = true;

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
        body: Stack(children: <Widget>[
      Center(
        /*child: Column(mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[

                      CircularProgressIndicator(),
                      Padding(
                        padding: const EdgeInsets.all(15.0),
                        child: Text("Loading"),
                      )
                    ],
                  )*/

        child: isLoading
            ?

        SizedBox(
          child: Shimmer.fromColors(
            baseColor: Colors.black12,
            highlightColor: Colors.white,
            child:

            Image.asset("images/shimmer.png",fit: BoxFit.fill,),
            /*  Text(
              'Loading',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 20.0,
                fontWeight:
                FontWeight.bold,
              ),
            ),*/
          ),
        )

    /*    Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  CircularProgressIndicator(),
                  Padding(
                    padding: const EdgeInsets.all(15.0),
                    child: Text("Loading"),
                  )
                ],
              )*/


            : Container(),
      ),
      ListView.builder(
        itemCount: offerOrdersData == null ? 0 : offerOrdersData.length,
        itemBuilder: (BuildContext context, int index) {
          return Container(
            height: 110.0,
            child: Card(
              child: Container(
                  child: Padding(
                padding: EdgeInsets.only(left: 10, right: 15),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    Padding(
                        padding: EdgeInsets.only(left: 10),
                        child: Container(
                            width: 60,
                            height: 60,
                            decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: Colors.blueAccent),
                            child: Center(
                              child: Text(
                                "ID " + offerOrdersData[index]['order_id'],
                                style: TextStyle(
                                    color: Colors.white,
                                    fontFamily: 'Montserrat'),
                                textAlign: TextAlign.center,
                              ),
                            ))),
                    SizedBox(
                      width: 40,
                    ),
                    Padding(
                        padding: EdgeInsets.only(top: 25),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            Expanded(
                              child: Text(
                                offerOrdersData[index]['delivered_status'],
                                style: TextStyle(
                                    color: Colors.black87,
                                    fontFamily: 'Montserrat'),
                                textAlign: TextAlign.center,
                              ),
                              flex: 1,
                            ),
                            Expanded(
                              child: Text(
                                offerOrdersData[index]['created_time'],
                                style: TextStyle(
                                    color: Colors.black87,
                                    fontFamily: 'Montserrat',
                                    fontSize: 11),
                                textAlign: TextAlign.center,
                              ),
                              flex: 1,
                            ),
                          ],
                        )),
                    SizedBox(
                      width: 60,
                    ),
                    Padding(
                      padding: EdgeInsets.only(top: 25),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          Expanded(
                            child: Text(
                              offerOrdersData[index]['created_date'],
                              style: TextStyle(
                                  color: Colors.black87,
                                  fontFamily: 'Montserrat',
                                  fontSize: 12),
                              textAlign: TextAlign.center,
                            ),
                            flex: 1,
                          ),
                          Expanded(
                            child: Text(
                              "ORDER CODE",
                              style: TextStyle(
                                  color: Colors.black54,
                                  fontFamily: 'Montserrat',
                                  fontSize: 10),
                              textAlign: TextAlign.center,
                            ),
                            flex: 1,
                          ),
                          Expanded(
                            child: Text(
                              offerOrdersData[index]['order_code'],
                              style: TextStyle(
                                  color: Colors.blueAccent,
                                  fontFamily: 'Montserrat',
                                  fontSize: 12),
                              textAlign: TextAlign.center,
                            ),
                            flex: 1,
                          ),
                        ],
                      ),
                    )
                  ],
                ),
              )),
            ),
          );
        },
      ),
    ]));
  }

  @override
  void initState() {
    isLoading = true;
    getPrefData().then(getLogState);
    getOfferOrders();
    super.initState();
  }

  Future<String> getPrefData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String userID = prefs.getString("userID");

    return userID;
  }

  void getLogState(String userID) {
    setState(() {
      print("ShareeVAla" + userID);

      this.userID = userID;
    });
  }

  @override
  void dispose() {
    loading = false;
    super.dispose();
  }

  Future<String> getOfferOrders() async {
    final url = Apis.offerOrder;
    SharedPreferences prefs = await SharedPreferences.getInstance();

    var response = await http.post(Uri.encodeFull(url),
        headers: {"Accept": "application/json"},
        body: {"user_id": userID, "secret_hash": "W9zUnkWf5wJS27Yb2Nmmz3T"});
    setState(() {
      isLoading = false;
    });


    if (response.statusCode == 200) {
      if (loading == true) {
        setState(() {
          Map<String, dynamic> offerOrders = jsonDecode(response.body);

          //  print("ProooductOBj" + response.body);

          offerOrdersData = offerOrders['Orders'];
        });
      }
    } else {}

    return "Sucess!";
  }
}
