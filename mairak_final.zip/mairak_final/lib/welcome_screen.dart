/*
 * Created by Aravind on 12/2/19 10:54 AM
 * Copyright (c) 2019 . All rights reserved.
 *  Last modified 12/2/19 10:54 AM
 */

import 'package:mairak_final/accounts/login.dart';
import 'package:mairak_final/accounts/registration.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class WelcomeScreen extends StatefulWidget {
  @override
  _WelcomeScreenState createState() => _WelcomeScreenState();
}

class _WelcomeScreenState extends State<WelcomeScreen> {
  bool _giveVerse = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Stack(
      children: <Widget>[
        Container(
          decoration: BoxDecoration(
            image: DecorationImage(
              image: AssetImage('images/splash_screen_bg.jpg'),
              fit: BoxFit.cover,
            ),
          ),
        ),
        Padding(
          padding: EdgeInsets.only(top: 130),
          child: Center(
            child: Column(
              children: <Widget>[
                Column(
                  children: <Widget>[
                    Image.asset(
                      "images/logo_main.png",
                      height: 215,
                      width: 215,
                    ),
                    Padding(
                      padding:
                          const EdgeInsets.only(top: 89, left: 25, bottom: 8),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: <Widget>[
                          Icon(
                            Icons.translate,
                            size: 15,
                          ),
                          SizedBox(
                            width: 10,
                          ),
                          Text(
                            "Language",
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 16,
                                fontFamily: 'Montserrat'),
                          )
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 0.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                          Padding(
                            padding: const EdgeInsets.only(left: 50.0),
                            child: Text(
                              "English",
                              style: TextStyle(fontFamily: 'Montserrat'),
                            ),
                          ),
                          Container(
                            child: Switch(
                              value: _giveVerse,
                              onChanged: (bool newValue) {
                                //  widget.chkLang();
                                setState(() {
                                  _changeLang(newValue);

                                  _giveVerse = newValue;
                                });
                              },
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(right: 50.0),
                            child: Text(
                              "Arabic",
                              style: TextStyle(fontFamily: 'Montserrat'),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(top: 15),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: <Widget>[
                          Padding(
                            padding: EdgeInsets.symmetric(vertical: 16.0),
                            child: RaisedButton(
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(24),
                              ),
                              onPressed: () {
                                Navigator.pushReplacement(
                                    context,
                                    new MaterialPageRoute(
                                        builder: (context) => LoginPage()));
                              },
                              padding: EdgeInsets.all(12),
                              // color: const Color(0xff07a7cf),
                              color: const Color(0xff1a606f),

                              child: Text('Login',
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontFamily: 'Montserrat')),
                            ),
                          ),
                          Padding(
                            padding: EdgeInsets.symmetric(vertical: 16.0),
                            child: RaisedButton(
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(24),
                              ),
                              onPressed: () {
                                Navigator.pushReplacement(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) => Registration()));
                              },
                              padding: EdgeInsets.all(12),
                              // color: const Color(0xff07a7cf),
                              color: const Color(0xff1a606f),

                              child: Text('Register',
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontFamily: 'Montserrat')),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                )
              ],
            ),
//                shrinkWrap: true,
//                padding: EdgeInsets.only(left: 24.0, right: 24.0),
          ),
        ),

        /* Container(
              decoration: new BoxDecoration(
                image: new DecorationImage(
                  image: new AssetImage(" images/sp_bg_comp.jpg"),
                  fit: BoxFit.fitHeight,
                ),
              ),
            ),
            */
        /*    Center(
        child: SplashImageWidgets(),
          )*/
      ],
    ));
  }

  Future _changeLang(bool newValue) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    print(newValue);
    if (newValue == true) {
      print("ImmmHeerrrr11");
      prefs.setString('language', "a");
    } else {
      print("ImmmHeerrrr22");
      prefs.setString('language', "e");
    }
  }





}
