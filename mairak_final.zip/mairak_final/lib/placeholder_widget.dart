/*
 * Created by Aravind on 12/13/18 12:14 PM
 * Copyright (c) 2018 . All rights reserved.
 *  Last modified 12/13/18 12:14 PM
 */

import 'package:flutter/material.dart';

class PlaceholderWidget extends StatelessWidget {
  final Color color;

  PlaceholderWidget(this.color);

  @override
  Widget build(BuildContext context) {
    return Container(
      color: color,
    );
  }
}