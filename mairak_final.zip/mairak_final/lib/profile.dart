/*
 * Created by Aravind on 1/29/19 12:10 PM
 * Copyright (c) 2019 . All rights reserved.
 *  Last modified 1/29/19 12:10 PM
 */

import 'dart:ui';

import 'package:mairak_final/allapi.dart';
import 'package:mairak_final/widgets.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
//import 'package:geocoder/geocoder.dart';
import 'package:flutter/services.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

//import 'package:image_picker/image_picker.dart';
//import 'package:camera/camera.dart';

class MyProfile extends StatefulWidget {
  @override
  _MyProfileState createState() => _MyProfileState();
}

class _MyProfileState extends State<MyProfile> {
  bool isChecked = false;
  final nameCtrl = TextEditingController();
  final phoneCtrl = TextEditingController();
  final altPhoneCtrl = TextEditingController();
  final emailCtrl = TextEditingController();
  final addrOCtrl = TextEditingController();
  final addrTCtrl = TextEditingController();
  final stateCtrl = TextEditingController();
  final pinCtrl = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  String lat = "0.0", lon = "0.0";

  String phNo = "",
      alternate = "",
      email = "",
      add1 = "",
      add2 = "",
      state = "",
      pin = "",
      areYou = "",
      mairak = "",
      update = "";
  String img = "";

  _chkLang() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    if (prefs.getString("language") == "a") {


      setState(() {
        phNo = "رقم الهاتف";
        alternate = "رقم الهاتف";
        email = "البريد الإلكتروني";
        add1 = "العنوان (1)";
        add2 = "العنوان (2)";
        state = "الدولة";
        pin = "رمز";
        areYou = "موظف حكومة ؟";
        update = "تحديث";
        mairak = "مايرك";

      });


    } else {


      setState(() {

        mairak = "Mai Rak";
        phNo = "Phone Number";
        alternate = "Alternate Phone Number";
        email = "Email";
        add1 = "Address 1";
        add2 = "Address 2";
        state = "State";
        pin = "Pin";
        areYou = "Are you a Govt Employee?";
        update = "UPDATE";

      });

    }
  }

  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.of(context).size.width;

    return Scaffold(
      key: _scaffoldKey,
      appBar: AppBar(
        elevation: 0.0,
        title: Text(
          "$mairak",
          style: TextStyle(
              color: Colors.white, fontFamily: 'Montserrat', fontSize: 22),
        ),
        centerTitle: true,
      ),
      body: Container(
        child: Stack(
          children: <Widget>[
            //  Image.asset("images/nav_bg.png",fit: BoxFit.fitHeight,),

            Container(
              color: Colors.blue,
              /*decoration:  BoxDecoration(
          //  color: Colors.black87
              image:  DecorationImage(
              image:
             ExactAssetImage('images/nav_bg.png'),
              fit: BoxFit.cover,
            ),
          ),
          child:  BackdropFilter(
            filter:
            ImageFilter.blur(sigmaX: 10.0, sigmaY: 10.0),
            child:  Container(
              decoration:  BoxDecoration(color: Colors.white.withOpacity(0.0)),
            ),
          ),*/
            ),

            Column(
              children: <Widget>[
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Padding(
                        padding: EdgeInsets.only(top: 35),
                        child: Stack(
                          children: <Widget>[
                            Container(
                                width: 95.0,
                                height: 95.0,
                                decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: Colors.black87,
                                    boxShadow: [
                                      new BoxShadow(
                                          color: Colors.black54,
                                          blurRadius: 10.0,
                                          offset: Offset(1, 3)),
                                    ],
                                    image: DecorationImage(
                                        fit: BoxFit.fill,
                                        image: NetworkImage(
                                            Uri.encodeFull(img))))),

                            /*
                            CircleAvatar(child:



                            CachedNetworkImage(

                              imageUrl: Uri.encodeFull(
                                  "http://inviewmart.com/mairak_api/assets/images/profile/user.png"),
                              placeholder: CircularProgressIndicator(
                                strokeWidth: 2,),
                              height: 100,
                              width: 90,
                              errorWidget: Icon(Icons.broken_image, size: 32,
                                color: Colors.grey,),)







                              // image: NetworkImage("http://inviewmart.com/mairak_api/assets/images/profile/user.png"),
                            //Image.asset("images/noimage.png")
                              ,radius: 55,backgroundColor: Colors.transparent
                              ,),
*/
                            GestureDetector(
                                onTap: () {
                                  _optionsDialogBox();
                                },
                                child: CircleAvatar(
                                  child: Icon(
                                    Icons.add_a_photo,
                                    size: 15,
                                    color: Colors.white,
                                  ),
                                  radius: 15,
                                ))
                          ],
                        )),
                  ],
                ),
                SizedBox(
                  height: 10,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Container(
                      width: width,
                      child: TextFormField(
                        keyboardType: TextInputType.number,
                        autofocus: false,
                        textAlign: TextAlign.center,
                        controller: nameCtrl,
                        style: TextStyle(
                          fontSize: 17,
                          fontFamily: 'Montserrat',
                          color: Colors.white,
                        ),
                        decoration: InputDecoration(
                          /*   contentPadding:
                          EdgeInsets.fromLTRB(3.0, 10.0, 20.0, 10.0),*/
                          border: InputBorder.none,
                          /*border:   UnderlineInputBorder(
                                borderSide:   BorderSide(
                                    color: Colors.white
                                )
                            )*/
                          // border: OutlineInputBorder(borderRadius: BorderRadius.circular(radius)),
                        ),
                      ),
                    )
                  ],
                )
              ],
            ),

            Padding(
              padding: const EdgeInsets.only(top: 200),
              child:


              Container(
                width: width,
                color: Colors.transparent,
                height: 398,
                child: Card(
                    margin: EdgeInsets.only(
                        left: 0.0, right: 0.0, top: 8.0, bottom: 0.0),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(20),
                            topRight: Radius.circular(20))),
                    elevation: 4.0,
                    color: Colors.white,
                    child: ListView(
                      children: <Widget>[
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Padding(
                              padding: const EdgeInsets.only(
                                  top: 15.0, bottom: 5, left: 15),
                              child: Text(
                                "$phNo",
                                style: TextStyle(
                                    color: Colors.grey,
                                    fontFamily: 'Montserrat',
                                    fontSize: 12),
                              ),
                            ),
                            Container(
                                width: width,
                                child: Padding(
                                  padding: EdgeInsets.only(right: 15, left: 15),
                                  child: TextFormField(
                                    controller: phoneCtrl,
                                    keyboardType: TextInputType.number,
                                    autofocus: false,
                                    style: TextStyle(
                                      fontFamily: 'Montserrat',
                                      color: Colors.black,
                                    ),
                                    decoration: InputDecoration(
                                      prefixIcon: Icon(
                                        Icons.phone,
                                        size: 15,
                                      ),
                                      /*hintStyle: TextStyle(color: Colors.grey),
                            hintText: 'Number',*/
                                      contentPadding: EdgeInsets.fromLTRB(
                                          3.0, 10.0, 20.0, 10.0),
                                      border: InputBorder.none,
                                      // border: OutlineInputBorder(borderRadius: BorderRadius.circular(3)),
                                    ),
                                  ),
                                )),
                            Padding(
                              padding: const EdgeInsets.only(
                                  top: 10.0, bottom: 5, left: 15),
                              child: Text(
                                "$alternate",
                                style: TextStyle(
                                    color: Colors.grey,
                                    fontFamily: 'Montserrat',
                                    fontSize: 12),
                              ),
                            ),
                            Container(
                                width: width,
                                child: Padding(
                                  padding: EdgeInsets.only(right: 15, left: 15),
                                  child: TextFormField(
                                    controller: altPhoneCtrl,
                                    keyboardType: TextInputType.number,
                                    autofocus: false,
                                    style: TextStyle(
                                      fontFamily: 'Montserrat',
                                      color: Colors.black,
                                    ),
                                    decoration: InputDecoration(
                                      prefixIcon: Icon(
                                        Icons.phone,
                                        size: 15,
                                      ),
                                      /*hintStyle: TextStyle(color: Colors.grey),
                            hintText: 'Number',*/
                                      contentPadding: EdgeInsets.fromLTRB(
                                          3.0, 10.0, 20.0, 10.0),
                                      border: InputBorder.none,
                                      /*border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(3)),*/
                                    ),
                                  ),
                                )),
                            Padding(
                              padding: const EdgeInsets.only(
                                  top: 10.0, bottom: 5, left: 15),
                              child: Text(
                                "$email",
                                style: TextStyle(
                                    fontFamily: 'Montserrat',
                                    color: Colors.grey,
                                    fontSize: 12),
                              ),
                            ),
                            Container(
                                width: width,
                                child: Padding(
                                  padding: EdgeInsets.only(right: 15, left: 15),
                                  child: TextFormField(
                                    controller: emailCtrl,
                                    keyboardType: TextInputType.emailAddress,
                                    autofocus: false,
                                    style: TextStyle(
                                      fontFamily: 'Montserrat',
                                      color: Colors.black,
                                    ),
                                    decoration: InputDecoration(
                                      prefixIcon: Icon(
                                        Icons.email,
                                        size: 15,
                                      ),
                                      contentPadding: EdgeInsets.fromLTRB(
                                          3.0, 10.0, 20.0, 10.0),
                                      border: InputBorder.none,
                                      /*  border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(3)),*/
                                    ),
                                  ),
                                )),
                            Padding(
                              padding: const EdgeInsets.only(
                                  top: 10.0, bottom: 5, left: 15),
                              child: Text(
                                "$add1",
                                style: TextStyle(
                                    color: Colors.grey,
                                    fontFamily: 'Montserrat',
                                    fontSize: 12),
                              ),
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              children: <Widget>[
                                Flexible(
                                  child: Padding(
                                    padding: EdgeInsets.only(left: 15),
                                    child: TextFormField(
                                      keyboardType: TextInputType.text,
                                      controller: addrOCtrl,
                                      autofocus: false,
                                      validator: (value) {
                                        if (value.isEmpty) {
                                          return 'Please enter a address';
                                        }
                                      },
                                      style: TextStyle(
                                          fontFamily: 'Montserrat',
                                          color: Colors.black87),
                                      decoration: InputDecoration(
                                        prefixIcon: Icon(
                                          Icons.location_on,
                                          size: 15,
                                        ),
                                        hintText: '',
                                        contentPadding: EdgeInsets.fromLTRB(
                                            3.0, 10.0, 20.0, 10.0),
                                        border: InputBorder.none,
                                        //  border: OutlineInputBorder(borderRadius: BorderRadius.circular(3)),
                                      ),
                                    ),
                                  ),
                                  flex: 3,
                                ),
                                Flexible(
                                  child: FlatButton(
                                    child: Image.asset(
                                      "images/pin1.png",
                                      height: 40,
                                      width: 40,
                                    ),
                                    onPressed: () {
                                      getGeoLocation();
                                    },
                                  ),
                                  flex: 1,
                                ),
                              ],
                            ),
                            Padding(
                              padding: const EdgeInsets.only(
                                  top: 8.0, bottom: 5, left: 15),
                              child: Text(
                                "$add2",
                                style: TextStyle(
                                    color: Colors.grey,
                                    fontFamily: 'Montserrat',
                                    fontSize: 12),
                              ),
                            ),
                            Container(
                                width: width,
                                child: Padding(
                                  padding: EdgeInsets.only(right: 15, left: 15),
                                  child: TextFormField(
                                    keyboardType: TextInputType.text,
                                    controller: addrTCtrl,
                                    autofocus: false,
                                    style: TextStyle(
                                      fontFamily: 'Montserrat',
                                      color: Colors.black,
                                    ),
                                    decoration: InputDecoration(
                                      prefixIcon: Icon(
                                        Icons.location_on,
                                        size: 15,
                                      ),
                                      /*hintStyle: TextStyle(color: Colors.grey),
                            hintText: 'Number',*/
                                      contentPadding: EdgeInsets.fromLTRB(
                                          3.0, 10.0, 20.0, 10.0),
                                      border: InputBorder.none,
                                      /*   border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(3)),*/
                                    ),
                                  ),
                                )),
                            Row(
                              children: <Widget>[
                                Flexible(
                                  child: Padding(
                                    padding: const EdgeInsets.only(right: 5),
                                    child: Column(
                                      children: <Widget>[
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.start,
                                          children: <Widget>[
                                            Padding(
                                              padding: const EdgeInsets.only(
                                                  top: 10.0,
                                                  bottom: 5,
                                                  left: 17),
                                              child: Text(
                                                "$state",
                                                style: TextStyle(
                                                    color: Colors.grey,
                                                    fontFamily: 'Montserrat',
                                                    fontSize: 12),
                                              ),
                                            ),
                                          ],
                                        ),
                                        Container(
                                            width: width,
                                            child: Padding(
                                              padding: EdgeInsets.only(
                                                  right: 15, left: 15),
                                              child: TextFormField(
                                                keyboardType:
                                                    TextInputType.text,
                                                autofocus: false,
                                                controller: stateCtrl,
                                                style: TextStyle(
                                                  fontFamily: 'Montserrat',
                                                  color: Colors.black,
                                                ),
                                                decoration: InputDecoration(
                                                  prefixIcon: Icon(
                                                    Icons.location_on,
                                                    size: 15,
                                                  ),
                                                  /*hintStyle: TextStyle(color: Colors.grey),
                                hintText: 'Number',*/
                                                  contentPadding:
                                                      EdgeInsets.fromLTRB(3.0,
                                                          10.0, 20.0, 10.0),
                                                  border: InputBorder.none,
                                                  /*  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(3)),*/
                                                ),
                                              ),
                                            )),
                                      ],
                                    ),
                                  ),
                                  flex: 1,
                                ),
                                Flexible(
                                  child: Padding(
                                    padding: const EdgeInsets.only(left: 5),
                                    child: Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: <Widget>[
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.start,
                                          children: <Widget>[
                                            Padding(
                                              padding: const EdgeInsets.only(
                                                  top: 10.0,
                                                  bottom: 5,
                                                  left: 17),
                                              child: Text(
                                                "$pin",
                                                style: TextStyle(
                                                    color: Colors.grey,
                                                    fontFamily: 'Montserrat',
                                                    fontSize: 12),
                                              ),
                                            ),
                                          ],
                                        ),
                                        Container(
                                            width: width,
                                            child: Padding(
                                              padding: EdgeInsets.only(
                                                  right: 15, left: 15),
                                              child: TextFormField(
                                                keyboardType:
                                                    TextInputType.number,
                                                autofocus: false,
                                                controller: pinCtrl,
                                                style: TextStyle(
                                                  fontFamily: 'Montserrat',
                                                  color: Colors.black,
                                                ),
                                                decoration: InputDecoration(
                                                  /*hintStyle: TextStyle(color: Colors.grey),
                                hintText: 'Number',*/
                                                  contentPadding:
                                                      EdgeInsets.fromLTRB(3.0,
                                                          10.0, 20.0, 10.0),
                                                  border: InputBorder.none,
                                                  /*    border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(3)),*/
                                                ),
                                              ),
                                            )),
                                      ],
                                    ),
                                  ),
                                  flex: 1,
                                ),
                              ],
                            ),
                            Padding(
                              padding:
                                  const EdgeInsets.only(top: 5.0, left: 15),
                              child: Row(
                                children: <Widget>[
                                  Checkbox(
                                    value: isChecked,
                                    onChanged: (bool value) {
                                      setState(() {
                                        isChecked = value;
                                        print("chkVal" + isChecked.toString());
                                      });
                                    },
                                  ),
                                  Text("$areYou",
                                      style: TextStyle(
                                          fontFamily: 'Montserrat',
                                          color: Colors.black54,
                                          fontSize: 14))
                                ],
                              ),
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                Container(
                                  width: width,
                                  child: Padding(
                                    padding: EdgeInsets.only(
                                        top: 3,
                                        bottom: 30,
                                        left: 25,
                                        right: 25),
                                    child: RaisedButton(
                                      shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(24),
                                      ),
                                      onPressed: () {
                                        _updateProfile();
                                      },
                                      padding: EdgeInsets.all(12),
                                      // color: const Color(0xff07a7cf),
                                      color: const Color(0xff1a606f),

                                      child: Text('$update',
                                          style: TextStyle(
                                              color: Colors.white,
                                              fontFamily: 'Montserrat')),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ],
                    )),
              ),
            )
          ],
        ),
      ),
    );
  }

  Future<void> _optionsDialogBox() {
    return showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            content: SingleChildScrollView(
              child: ListBody(
                children: <Widget>[
                  GestureDetector(
                    child: Text('Take a picture'),
                    //  onTap: openCamera,
                  ),
                  Padding(
                    padding: EdgeInsets.all(10.0),
                  ),
                  GestureDetector(
                    child: Text('Select from gallery'),
                    //   onTap: openGallery,
                  ),
                ],
              ),
            ),
          );
        });
  }

  getGeoLocation() async {
/*    try {
      var position = await Geolocator()
          .getLastKnownPosition(desiredAccuracy: LocationAccuracy.high);
      // print(position.latitude.toString() + " :::::::::::: " + position.longitude.toString()+ " ::::::::: " + position.altitude.toString());
      lat = position.latitude.toString();
      lon = position.longitude.toString();
      final coordinates = Coordinates(position.latitude, position.longitude);
      var addresses =
          await Geocoder.local.findAddressesFromCoordinates(coordinates);
      var first = addresses.first;
      print(
          "${first.featureName} : ${first.subLocality} : ${first.adminArea} : ${first.postalCode}");

      setState(() {
        addrOCtrl.text = first.featureName.toString().trim();
        addrTCtrl.text = first.subLocality.toString().trim();
        stateCtrl.text = first.adminArea.toString().trim();
        pinCtrl.text = first.postalCode.toString().trim();
      });
    } on PlatformException {}*/
  }




  @override
  void initState() {
    super.initState();
    _chkLang();
    _getProfileData();
  }

  Future<void> _getProfileData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String userID = prefs.getString("userID");

    final url = Apis.myProfile;
    var response = await http.post(Uri.encodeFull(url),
        headers: {"Accept": "application/json"}, body: {"user_id": userID});

    print(response.body);

    if (response.statusCode == 200) {
      Map<String, dynamic> profile = jsonDecode(response.body);

      nameCtrl.text = profile['profile']['user_name'];
      phoneCtrl.text = profile['profile']['phone_number'];
      altPhoneCtrl.text = profile['profile']['alternate_phonenumber'];
      emailCtrl.text = profile['profile']['email'];
      addrOCtrl.text = profile['profile']['address_one'];
      addrTCtrl.text = profile['profile']['address_two'];
      stateCtrl.text = profile['profile']['state'];
      pinCtrl.text = profile['profile']['pincode'];

      setState(() {
        img = profile['profile']['images'];
      });

      if (profile['profile']['govt_employee'] == "yes") {
        setState(() {
          isChecked = true;
        });
      }
    } else {}
  }

  Future<void> _updateProfile() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String userID = prefs.getString("userID");

    final url = Apis.updateProfile;

    String emp;
    if (isChecked == true) {
      emp = "yes";
    } else {
      emp = "no";
    }
    var response = await http.post(Uri.encodeFull(url), headers: {
      "Accept": "application/json"
    }, body: {
      "user_id": userID,
      "full_name": nameCtrl.text,
      "phone_number": phoneCtrl.text,
      "alternate_phonenumber": altPhoneCtrl.text,
      "is_govtemployee": emp,
      "latitude": lat,
      "longitude": lon,
      "address_one": addrOCtrl.text,
      "address_two": addrTCtrl.text,
      "state": stateCtrl.text,
      "pincode": pinCtrl.text,
      "profile_image": "",
      "email": emailCtrl.text
    });

    print(response.body);

    if (response.statusCode == 200) {
      Map<String, dynamic> profileStat = jsonDecode(response.body);

      _scaffoldKey.currentState.showSnackBar(
          SnackBar(content: Text("${profileStat['Response']['message']}")));

      _getProfileData();
    }
  }
}
