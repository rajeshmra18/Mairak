import 'dart:convert';

import 'package:mairak_final/my_preorders.dart';
import 'package:mairak_final/notifications.dart';
/**
 * Created by Aravind on 12/13/18 12:09 PM
 * Copyright (c) 2018 . All rights reserved.
 *  Last modified 12/13/18 12:09 PM
 **/

import 'package:mairak_final/productListing/ProductListInflate.dart';
import 'package:mairak_final/profile.dart';
import 'package:mairak_final/settings.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:mairak_final/accounts/login.dart';
import 'cart.dart';
import 'dart:async';
import 'package:flutter/cupertino.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'my_orders.dart';
import 'allapi.dart';
import 'package:http/http.dart' as http;
import 'offer_listing.dart';
//import 'package:advanced_share/advanced_share.dart';
import 'offer_orders.dart';

class DrawerItem {
  String title;
  IconData icon;

  DrawerItem(this.title, this.icon);
}

class Home extends StatefulWidget {
  static String tag = 'home-page';
  final drawerItems = [
    DrawerItem("Home", Icons.home),
    DrawerItem("Offers", Icons.all_inclusive),
    DrawerItem("Orders", Icons.cloud_done),
    DrawerItem("Settings", Icons.settings),
    DrawerItem("Logout", Icons.exit_to_app),
  ];

  @override
  State<StatefulWidget> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  int _currentIndex = 0;
  double _badgeOpVal=0.0 ;
  int _selectedDrawerIndex = 0;
  int badgeCount = 0;
  String uName = "", uPhone = "", uImg = "";
  int cartStat = 0;
  String _appUrl = "", _refCode = "", userID = "";
  String title = "Mai Rak";
  String home = "Home",
      offers = "Offers",
      orders = "Orders",
      offerOrders = "Offer Orders",
      notifications = "Notifications";
  String myPreOrders = "My Pre Orders",
      myProfile = "My Profile",
      settings = "settings",
      share = "Share",
      logOut = "Logout",
      cancel = "",
      doYouLog = "";

  List notificationLists;

  _getDrawerItemWidget(int pos) {
    {
      switch (pos) {
        case 0:
          return ProductListInflate(getBadgeCount);
        case 1:
          return OfferListing();
        case 2:
          return MyOrders();
        case 3:
          return OfferOrder();
        case 4:
          return Notifications();

        default:
          return Text("Error");
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
    var drawerOptions = <Widget>[];
    for (var i = 0; i < widget.drawerItems.length; i++) {
      var d = widget.drawerItems[i];
      drawerOptions.add(new ListTile(
        leading: new Icon(d.icon),
        title: new Text(d.title),
        selected: i == _selectedDrawerIndex,
        onTap: () => _onSelectItem(i),
      ));
    }

    return Scaffold(
        appBar: AppBar(
          title: Text(
            "$title",
            style: TextStyle(
                color: Colors.white, fontFamily: 'Montserrat', fontSize: 22),
          ),
          actions: <Widget>[
            Padding(
                padding: const EdgeInsets.only(right: 22, bottom: 5),
                child: Stack(
                  children: <Widget>[
                    IconButton(
                      icon: Icon(
                        Icons.shopping_cart,
                        size: 27,
                      ),
                      tooltip: 'Cart',
                      onPressed: _cart,
                    ),
                     Positioned(
                      right: 7,
                      top: 6,
                      child: Container(
                          padding: EdgeInsets.all(1),
                          decoration: BoxDecoration(
                            color: Colors.red,
                            borderRadius: BorderRadius.circular(7),
                          ),
                          constraints: BoxConstraints(
                            minWidth: 14,
                            minHeight: 14,
                          ),
                          child: Center(
                              child: Text(
                            badgeCount.toString(),
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 9,
                            ),
                            textAlign: TextAlign.center,
                          ))),
                    )
                  ],
                ))
          ],
          centerTitle: true,
        ),
        drawer: SizedBox(
          width: 255,
          child: Drawer(
            child: ListView(
              children: <Widget>[
                UserAccountsDrawerHeader(
                  accountName: Text("$uName",
                      style: TextStyle(
                        fontFamily: 'Montserrat',
                      )),
                  accountEmail: Text("$uPhone",
                      style: TextStyle(
                        fontFamily: 'Montserrat',
                      )),
                  currentAccountPicture: DecoratedBox(
                      decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: Colors.blue,
                          boxShadow: [
                              BoxShadow(
                                color: Colors.black87,
                                blurRadius: 10.0,
                                offset: Offset(1, 3)),
                          ],
                          image: DecorationImage(
                              fit: BoxFit.fill,
                              image: NetworkImage(Uri.encodeFull(uImg))))),

                  /*  CircleAvatar(
                    backgroundImage: NetworkImage(Uri.encodeFull(uImg))
                  ),*/
                  decoration: BoxDecoration(
                    image: DecorationImage(
                      image: ExactAssetImage('images/nav_bg.png'),
                      fit: BoxFit.fill,
                    ),
                  ),

                  /*    currentAccountPicture: CircleAvatar(
             */ /*     backgroundImage: NetworkImage(
                      "https://randomuser.me/api/portraits/men/46.jpg")*/ /*

           //  backgroundImage: Image.asset("images/nav_bg.png")


              ),*/
                ),
                ListTile(
                    leading: Icon(Icons.access_time),
                    title: Text("$myPreOrders",
                        style: TextStyle(
                          fontFamily: 'Montserrat',
                        )),
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => MyPreOrder()));
                    }),
                ListTile(
                    leading: Icon(Icons.account_circle),
                    title: Text("$myProfile",
                        style: TextStyle(
                          fontFamily: 'Montserrat',
                        )),
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(context,
                          MaterialPageRoute(builder: (context) => MyProfile()));
                    }),
                ListTile(
                    leading: Icon(Icons.settings),
                    title: Text("$settings",
                        style: TextStyle(
                          fontFamily: 'Montserrat',
                        )),
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => Settings(chkLang)));

                      /*            Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) =>   MyHomePage()));*/
                    }),
                Divider(),
                ListTile(
                    leading: Icon(Icons.share),
                    title: Text("$share",
                        style: TextStyle(
                          fontFamily: 'Montserrat',
                        )),
                    onTap: () {
                     /* AdvancedShare.generic(
                        msg:
                            "$_appUrl \n To get additional benefits use this code : $_refCode",
                        title: "Share and get benefits",
                      ).then((response) {
                        print(response);
                      });*/
                      Navigator.pop(context);
                    }),
                ListTile(
                    leading: Icon(Icons.power_settings_new),
                    title: Text("$logOut",
                        style: TextStyle(
                          fontFamily: 'Montserrat',
                        )),
                    onTap: () {
                      Navigator.pop(context);
                      _showDialog();
                    }),
              ],
            ),
          ),
        ),
        body: _getDrawerItemWidget(_currentIndex),
        /*  floatingActionButton: FloatingActionButton(onPressed: (){

        },backgroundColor: Colors.red,child: Icon(Icons.add),),
        floatingActionButtonLocation: FloatingActionButtonLocation.endDocked,
        */
        bottomNavigationBar: Theme(
          isMaterialAppTheme: true,
          data: Theme.of(context).copyWith(
              selectedRowColor: Colors.red,
              // sets the background color of the `BottomNavigationBar`
              canvasColor: Colors.blue,
              // sets the active color of the `BottomNavigationBar` if `Brightness` is light
              primaryColor: Colors.red,
              textTheme: Theme.of(context)
                  .textTheme
                  .copyWith(caption: new TextStyle(color: Colors.yellow))),
          child: BottomNavigationBar(
            fixedColor: Colors.red,
            onTap: onTabTapped, // new
            currentIndex: _currentIndex, // new
            items: [
              BottomNavigationBarItem(
                icon: Icon(Icons.home),
                title: Text(
                  '$home',
                  style: TextStyle(
                    fontFamily: 'Montserrat',
                  ),
                ),
              ),
              new BottomNavigationBarItem(
                icon: Icon(Icons.whatshot),
                title: Text(
                  '$offers',
                  style: TextStyle(
                    fontFamily: 'Montserrat',
                  ),
                ),
              ),
              new BottomNavigationBarItem(
                icon: Icon(Icons.assignment_turned_in),
                title: Text(
                  '$orders',
                  style: TextStyle(
                    fontFamily: 'Montserrat',
                  ),
                ),
              ),
              new BottomNavigationBarItem(
                icon: Icon(Icons.clear_all),
                title: Text(
                  '$offerOrders',
                  style: TextStyle(
                    fontFamily: 'Montserrat',
                  ),
                ),
              ),
              BottomNavigationBarItem(
                  icon: Stack(children: <Widget>[
                    Icon(Icons.notifications),
                    Positioned(
                      // draw a red marble
                      top: 0.0,
                      right: 1.8,
                      child: Opacity(
                        opacity: _badgeOpVal,
                        child: Icon(Icons.brightness_1,
                            size: 8.0, color: Colors.redAccent),
                      ),
                    )
                  ]),
                  title: Text(
                    '$notifications',
                    style: TextStyle(
                      fontFamily: 'Montserrat',
                    ),
                  ))
            ],
          ),
        ));
  }

  _cart() {
    Navigator.push(context,
        MaterialPageRoute(builder: (context) => CartPage(getBadgeCount)));

/*    Navigator.push(
        context, MaterialPageRoute(builder: (context) => CartPage()));*/
  }

  _onSelectItem(int index) {
    setState(() => _selectedDrawerIndex = index);

    Navigator.of(context).pop(); // close the drawer
  }

  onTabTapped(int index) {
    setState(() {
      _currentIndex = index;
    });
  }

  void _showDialog() {
    // flutter defined function

    Future.delayed(Duration(milliseconds: 100)).then((_) {
      showDialog(
        context: context,
        builder: (BuildContext context) {
          // return object of type Dialog
          return AlertDialog(
            title: Text(
              "$logOut !",
              style: TextStyle(
                  fontFamily: 'Montserrat', fontWeight: FontWeight.bold),
            ),
            content: Text(
              "$doYouLog",
              style: TextStyle(fontFamily: 'Montserrat'),
            ),
            actions: <Widget>[
              FlatButton(
                child: new Text(
                  "$logOut",
                  style: TextStyle(fontFamily: 'Montserrat'),
                ),
                onPressed: () {
                  // Navigator.of(context).pop();

                  updateLogout();
                  Navigator.push(
                      context,
                      new MaterialPageRoute(
                          builder: (context) => new LoginPage()));
                },
              ),
              // usually buttons at the bottom of the dialog
              FlatButton(
                child: Text(
                  "$cancel",
                  style: TextStyle(fontFamily: 'Montserrat'),
                ),
                onPressed: () {
                  Navigator.of(context).pop();
                },
              ),
            ],
          );
        },
      );
    });
  }

  @override
  void initState() {
    chkLang();
    getNotifications();
    getSharedData();
    _getProfileData();
    // _getBadgeCount();
    super.initState();
  }

  /* callBack() {
  _getBadgeCount();
  }*/

  Future<String> getBadgeCount() async {
    final url2 = Apis.myCart;
    SharedPreferences prefs2 = await SharedPreferences.getInstance();
    userID = prefs2.getString("userID");

    Future.delayed(Duration(seconds: 10));
    print(userID);
    var response = await http.post(Uri.encodeFull(url2),
        headers: {"Accept": "application/json"},
        body: {"userid": userID, "language": "e"});

    // print("rEEESSPPSPSPSpppppppBad" + response.body);

    if (response.statusCode == 200) {
      Map<String, dynamic> cart = jsonDecode(response.body);

      // print('HowdyCart, ${cart['Response'][0][0]['total']}!');

      setState(() {
        badgeCount = cart['Response']['total'];
      });
    } else {
      print(Exception);
      throw Exception('Failed to load post');
    }

    return "Sucess!";
  }

  getSharedData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      _refCode = prefs.getString("refCode");
      _appUrl = prefs.getString("appUrl");
      userID = prefs.getString("userID");
    });
  }

  Future<void> _getProfileData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String userID = prefs.getString("userID");

    final url = Apis.myProfile;
    var response = await http.post(Uri.encodeFull(url),
        headers: {"Accept": "application/json"}, body: {"user_id": userID});

    // print(response.body);

    if (response.statusCode == 200) {
      Map<String, dynamic> profile = jsonDecode(response.body);

      setState(() {
        uName = profile['profile']['user_name'];
        uPhone = profile['profile']['phone_number'];
        uImg = profile['profile']['images'];
      });
    } else {}
  }

  chkLang() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    if (prefs.getString("language") == "a") {
      title = "مايرك";
      home = "الرئيسية";
      offers = "العروض";
      orders = "الطلبات الخاصة بي";
      offerOrders = "العروض على الطلبات الخاصة بي";
      notifications = "إخطار";
      cancel = "إلغاء";
      doYouLog = "هل أنت متأكد أنك تود الخروج ؟";
      myPreOrders = "الطلبات المقدمة";
      myProfile = "الملف الشخصي الخاص بي";
      settings = "الإعدادات";
      share = "مشاركة – يتقاسم";
      logOut = "الخروج";
    } else {
      title = "Mai Rak";
      home = "Home";
      offers = "Offers";
      orders = "Orders";
      offerOrders = "Offer Orders";
      notifications = "Notifications";
      cancel = "cancel";
      doYouLog = "Do you wanna Logout?";
      myPreOrders = "My Pre Orders";
      myProfile = "My Profile";
      settings = "settings";
      share = "Share";
      logOut = "Logout";
    }
  }


  Future<String> getNotifications() async {
    final url = Apis.getNotifications;

    SharedPreferences prefs2 = await SharedPreferences.getInstance();
    String userID = prefs2.getString("userID");
    print(userID);
    String uID = userID;
    var response = await http.post(Uri.encodeFull(url),
        headers: {"Accept": "application/json"},
        body: {"userid": uID, "secret_hash": "W9zUnkWf5wJS27Yb2Nmmz3T"});
    print(userID);

    print(response.body);
    if (response.statusCode == 200) {
      setState(() {
        Map<String, dynamic> notifi = jsonDecode(response.body);
        print(response.body);
        notificationLists = notifi['Notification'];

        if( notificationLists == null){
          setState(() {
            _badgeOpVal =0.0;
          });

        }
        else{
          setState(() {
            _badgeOpVal = 1.0;
          });
        }


      });

    } else {}

    return "Sucess!";
  }



}

updateLogout() async {
  SharedPreferences prefs = await SharedPreferences.getInstance();
  prefs.setString('loggedin', "N");
}






/*
class MyCustomRoute<T> extends MaterialPageRoute<T> {
  MyCustomRoute({ WidgetBuilder builder, RouteSettings settings })
      : super(builder: builder, settings: settings);

  @override
  Widget buildTransitions(BuildContext context,
      Animation<double> animation,
      Animation<double> secondaryAnimation,
      Widget child) {
    if (settings.isInitialRoute)
      return child;
    // Fades between routes. (If you don't want any animation,
    // just return child.)
    return   RotationTransition(turns:animation, child: child);
  }
}*/
