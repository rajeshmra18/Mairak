/*
 * Created by Aravind on 1/15/19 5:20 PM
 * Copyright (c) 2019 . All rights reserved.
 *  Last modified 1/15/19 5:20 PM
 */

class Apis {
  static String mainDomain = "http://inviewmart.com/mairakApiNew/";

  // static String mainDomain = "http://inviewmart.com/mairak_api_ios/";

  static String loginApi = mainDomain + "Login.php";
  static String productsList = mainDomain + "Product.php";
  static String addToCart = mainDomain + "Add_to_cart.php";
  static String myOrders = mainDomain + "Myorder.php";
  static String myOffers = mainDomain + "Offer.php";
  static String myCart = mainDomain + "My_cart.php";
  static String offerOrder = mainDomain + "Myorder_offer.php";
  static String cartList = mainDomain + "My_cart.php";
  static String deleteCart = mainDomain + "Delete_cart.php";
  static String bookOffer = mainDomain + "Offer_order.php";
  static String registerUser = mainDomain + "Register.php";
  static String otpVerification = mainDomain + "Otp_verification.php";
  static String getNotifications = mainDomain + "Pushnotification.php";
  static String delNotifications = mainDomain + "Pushnotification_delete.php";
  static String readNotifications = mainDomain + "Notification_read.php";
  static String myPreOrder = mainDomain + "Mypreorder.php";
  static String myProfile = mainDomain + "Myprofile.php";
  static String updateProfile = mainDomain + "Profile_update.php";
  static String cartOrder = mainDomain + "Cart_order.php";
  static String applyPromo = mainDomain + "Promo_code.php";
  static String cartInfo = mainDomain + "Cart_info.php";
  static String preOrder = mainDomain + "Preorder.php";
}
