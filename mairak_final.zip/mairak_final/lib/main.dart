/**
 * Created by Aravind on 12/13/18 11:46 AM
 * Copyright (c) 2018 . All rights reserved.
 * Last modified 12/13/18 11:46 AM
 **/

import 'dart:async';

import 'package:mairak_final/accounts/login.dart';
import 'package:mairak_final/home.dart';
import 'package:mairak_final/welcome_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: SplashScreen(),
    routes: <String, WidgetBuilder>{
      '/Login': (BuildContext context) => LoginPage()
    },
  ));
}

Future<String> getPrefData() async {
  SharedPreferences prefs = await SharedPreferences.getInstance();
  String logVal = prefs.getString("loggedin");

  return logVal;
}

class SplashScreen extends StatefulWidget {
  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  String logedValue = "";

  startTime() async {
    var _duration = Duration(seconds: 4);
    return Timer(_duration, navigationPage);
  }

  void navigationPage() {
    if (logedValue == "y") {
      Navigator.pushReplacement(
          context, MaterialPageRoute(builder: (context) => Home()));
    } else {
      Navigator.pushReplacement(
          context, MaterialPageRoute(builder: (context) => WelcomeScreen()));

      /* Navigator.of(context).pushReplacementNamed('/Login');*/
    }
  }

  @override
  Widget build(BuildContext context) {
    // SystemChrome.setEnabledSystemUIOverlays([]);
    return SafeArea(
      child: Scaffold(
          body: Stack(
        children: <Widget>[
          Container(
            decoration: BoxDecoration(
              image: DecorationImage(
                image: AssetImage('images/splash_screen_bg.jpg'),
                fit: BoxFit.cover,
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.only(top: 130),
            child: Center(
              child: Column(
                children: <Widget>[
                  Column(
                    children: <Widget>[
                      Image.asset(
                        "images/logo_main.png",
                        height: 215,
                        width: 215,
                      ),
                      Padding(
                          padding: EdgeInsets.only(top: 89),
                          child: Text("In Corporation With",
                              style: TextStyle(
                                  color: Colors.black,
                                  fontFamily: 'Montserrat'))),
                      Padding(
                          padding: EdgeInsets.only(top: 15),
                          child: Image.asset(
                            "images/reg_logo.png",
                            height: 80,
                            width: 80,
                          )),
                      Padding(
                          padding: EdgeInsets.only(top: 25),
                          child:
                          Text("A Program by RAK HR Department" ,style: TextStyle(color: Colors.red,fontFamily: 'Montserrat'),)
                          
                     /*     
                          Image.asset(
                            "images/rakg_logo.png",
                            height: 45,
                            width: 180,
                          )*/
                      ),
                    ],
                  )
                ],
              ),
//                shrinkWrap: true,
//                padding: EdgeInsets.only(left: 24.0, right: 24.0),
            ),
          ),

          /* Container(
                decoration: new BoxDecoration(
                  image: new DecorationImage(
                    image: new AssetImage(" images/sp_bg_comp.jpg"),
                    fit: BoxFit.fitHeight,
                  ),
                ),
              ),
              */
          /*    Center(
          child: SplashImageWidgets(),
            )*/
        ],
      )),
    );
  }

  @override
  void initState() {
    getPrefData().then(getLogState);
    super.initState();
    startTime();
  }

  void getLogState(String logedValue) {
    setState(() {
      print("ShareeVAla $logedValue");

      this.logedValue = logedValue;
    });
  }
}
